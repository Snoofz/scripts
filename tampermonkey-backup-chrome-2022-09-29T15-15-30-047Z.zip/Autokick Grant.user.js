// ==UserScript==
// @name         Autokick Grant
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

MPP.client.on("participant added", p => {
    if (p._id == "1ca77b9b8b30de49e984f5ef") {
        MPP.client.sendArray([{m:'kickban', _id: "1ca77b9b8b30de49e984f5ef" || "8be161844ae988e7c0f04dd1", ms:60*60*1000}]);
    }
});