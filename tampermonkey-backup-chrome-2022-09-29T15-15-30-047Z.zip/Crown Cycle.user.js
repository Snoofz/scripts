// ==UserScript==
// @name         Crown Cycle
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.net/*
// @match        https://www.multiplayerpiano.dev/*
// @icon         https://www.google.com/s2/favicons?domain=multiplayerpiano.net
// @grant        none
// ==/UserScript==

let currentid = "I made this clone :D";

getUser = i => { let out; for (let id in MPP.client.ppl) { let p = MPP.client.ppl[id]; if (p._id.toLowerCase().includes(i.toLowerCase())) { out = p; } } return out; };

crownCycle = () => {
    let time = 0;
    setTimeout(() => {
        Object.keys(MPP.client.ppl).forEach(key => {
               MPP.client.sendArray([{m:"chown", id: key}]);
        });
        time += 3000;
    }, time);
}
