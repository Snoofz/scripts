// ==UserScript==
// @name         Starfield
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  MPP starfield script
// @author       Hri7566
// @match        https://mppclone.com/*
// @match        https://www.multiplayerpiano.org/*
// @match        https://piano.ourworldofpixels.com/*
// @match        https://mppkinda.com/*
// @match        https://www.multiplayerpiano.dev/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

// @match        https://mpp.hri7566.info/*
function genStarSize() {
    if (Math.random() < 0.01) {
        return 10;
    } else {
        return 3;
    }
}

function spawnStar() {
    let pos = {
        x: Math.random() * 100,
        y: Math.random() * 100
    }

    let jqstar = $('<div id="star"></div>').appendTo(document.body);
    let starSize = genStarSize();

    jqstar.css({
        "left": pos.x + "%",
        "top": pos.y + "%",
        "z-index": "-100",
        "background-color": "#bbb",
        "display": "inline-block",
        "border-radius": "50%",
        "position": "absolute",
        "width": starSize + "px",
        "height": starSize + "px",
        "display": "none",
        "box-shadow": `0 0 ${starSize/2}px ${starSize/2}px #bbb`
    });

    $(jqstar).fadeIn(1000, () => {
        $(jqstar).fadeOut(30000, () => {
            $(jqstar).remove();
        });
    });
}

window.starInterval = setInterval(() => {
    setTimeout(spawnStar, Math.random() * 1000)
}, 250);
