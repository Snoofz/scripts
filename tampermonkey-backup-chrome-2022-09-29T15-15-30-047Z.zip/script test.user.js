// ==UserScript==
// @name         script test
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

window.addEventListener('beforescriptexecute',
  function(event)
  {
    var originalScript = event.target;

    // debug output of full qualified script url
    console.log('script detected:', originalScript.src);

    // script ends with 'originalscript.js' ?
    // you can test as well: '<full qualified url>' === originalScript.src
    if(/\/originalscript\.js$/.test(originalScript.src))
    {
      var replacementScript = document.createElement('script');
      replacementScript.src = 'replacementscript.js';
/*
      originalScript.parentNode.replaceChild(replacementScript, originalScript);

      // prevent execution of the original script
      event.preventDefault();
*/
    }
  }
);