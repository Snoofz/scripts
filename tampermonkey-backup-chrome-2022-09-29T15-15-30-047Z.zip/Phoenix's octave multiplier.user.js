// ==UserScript==
// @name         Phoenix's octave multiplier
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

var octTemp = {
    octLevel: 5
};

$("body").append('<div id="octave-btn" class="ugly-button" style="bottom: 22px; right: 640px; position: fixed; z-index: 500;">Octave Level</div>');
$("#octave-btn").on("click", function(evt) {
    var isNumber = Number.isInteger || function(number) {
        return !isNaN(parseFloat(n)) && isFinite(n);
    };
    var result = prompt("Enter Octave Level (MAX 5)");
    if (result > 6  || result < 1) {
        prompt("That number is too high, or too low!");
        octTemp.octLevel = 1;
    } else {
        octTemp.octLevel = result;
    }

});

function press(id, vol) {
    if (!gClient.preventsPlaying() && gNoteQuota.spend(1)) {
        gHeldNotes[id] = true;
        gSustainedNotes[id] = true;
        gPiano.play(id, vol !== undefined ? vol : DEFAULT_VELOCITY, gClient.getOwnParticipant(), 0);
        gClient.startNote(id, vol);
    }
}


function press(id, vol) {
    //used to have an if gClient.preventsPlaying()
    if (delPlay) {
        setTimeout(function() {
            gPiano.play(id, vol !== undefined ? vol : DEFAULT_VELOCITY, gClient.getOwnParticipant(), 0);
            gClient.startNote(id + oct, vol);
        }, delTime);
    }

    gHeldNotes[id] = true;
    gSustainedNotes[id] = true;
    var octave = parseInt(id.replace(/[^\d.]/, '').replace('s', ''));
    var note = id.replace(/[0-9]/g, '').replace("-", "");

    function pressDown(pressed, oct) {
        gPiano.play(pressed + oct, vol !== undefined ? vol : DEFAULT_VELOCITY, gClient.getOwnParticipant(), 0);
        gClient.startNote(pressed + oct, vol);


    }
    if (!rollTemp && octTemp.octLevel == 1) {
        pressDown(note, octave);
    }
    if (!rollTemp && octTemp.octLevel == 2) {
        pressDown(note, octave);
        pressDown(note, (octave - 1));
    }
    if (!rollTemp && octTemp.octLevel == 3) {
        pressDown(note, octave);
        pressDown(note, (octave - 1));
        pressDown(note, (octave + 1));
    }
    if (!rollTemp && octTemp.octLevel == 4) {
        pressDown(note, octave);
        pressDown(note, (octave - 1));
        pressDown(note, (octave + 1));
        pressDown(note, (octave - 2));
    }
    if (!rollTemp && octTemp.octLevel == 5) {
        pressDown(note, octave);
        pressDown(note, (octave - 1));
        pressDown(note, (octave + 1));
        pressDown(note, (octave - 2));
        pressDown(note, (octave + 2));
    }
    if (rollTemp && octTemp.octLevel == 1) {
        pressDown(note, octave);
    }
    if (rollTemp && octTemp.octLevel == 2) {
        setTimeout(function() {
            pressDown(note, octave);
        }, 50);
        pressDown(note, (octave - 1));
    }
    if (rollTemp && octTemp.octLevel == 3) {
        setTimeout(function() {
            pressDown(note, octave);
        }, 50);
        pressDown(note, (octave.octLevel - 1));
        setTimeout(function() {
            pressDown(note, (octave + 1));
        }, 100);
    }
    if (rollTemp && octTemp.octLevel == 4) {
        setTimeout(function() {
            pressDown(note, octave);
        }, 100);
        setTimeout(function() {
            pressDown(note, (octave - 1));
        }, 50);
        setTimeout(function() {
            pressDown(note, (octave + 1));
        }, 150);
        pressDown(note, (octave - 2));
    }
    if (rollTemp && octTemp.octLevel == 5) {
        setTimeout(function() {
            pressDown(note, octave);
        }, 100);
        setTimeout(function() {
            pressDown(note, (octave - 1));
        }, 50);
        setTimeout(function() {
            pressDown(note, (octave + 1));
        }, 150);
        pressDown(note, (octave - 2));
        setTimeout(function() {
            pressDown(note, (octave + 2));
        }, 200);
    }
}




function release(id) {
    if (gHeldNotes[id]) {
        gHeldNotes[id] = false;
        if ((gAutoSustain || gSustain) && !enableSynth) {
            gSustainedNotes[id] = true;
        } else {
            if (gNoteQuota.spend(1)) {
                gPiano.stop(id, gClient.getOwnParticipant(), 0);
                gClient.stopNote(id);
                gSustainedNotes[id] = false;
            }
        }
    }
}

function pressSustain() {
    gSustain = true;
}

function releaseSustain() {
    gSustain = false;
    if (!gAutoSustain) {
        for (var id in gSustainedNotes) {
            if (gSustainedNotes.hasOwnProperty(id) && gSustainedNotes[id] && !gHeldNotes[id]) {
                gSustainedNotes[id] = false;
                if (gNoteQuota.spend(1)) {
                    gPiano.stop(id, gClient.getOwnParticipant(), 0);
                    gClient.stopNote(id);
                }
            }
        }
    }
}
