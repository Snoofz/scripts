// ==UserScript==
// @name         fuckin vote
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @grant        none
// ==/UserScript==

MPP.client.on('a', msg => {
    if (msg.a.startsWith("voteban")) MPP.chat.send("Voted to kickban " + msg.a.substring(msg.a.split(" ")[0].length) +" from the channel for 60 minutes.")
});
