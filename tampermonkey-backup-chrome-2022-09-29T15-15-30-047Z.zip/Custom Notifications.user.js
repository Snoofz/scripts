// ==UserScript==
// @name         Custom Notifications
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  try to take over the world!
// @author       Hri7566
// @match        https://multiplayerpiano.com/*
// @match        https://mppclone.com/*
// @match        https://www.multiplayerpiano.org/*
// @icon         https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://mppclone.com&size=128
// @grant        none
// ==/UserScript==

MPP.client.sendArray([{
    m:"+custom"
}]);

MPP.client.on('custom', msg => {
    let m = msg.data;
    if (!m.m) return;
    if (m.m !== 'notification') return;
    new MPP.Notification(m);
});
