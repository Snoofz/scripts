// ==UserScript==
// @name         Speech to Text
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

function capitalizeFirstLetter(string) {
    return string;
};

var Voice = new webkitSpeechRecognition();
var listening = false;
Voice.continuous = true;
Voice.interimResults = true;
Voice.onresult = function(event) {
    console.log(event)
    if (event.results.length > 0) {
        var result = event.results[event.results.length - 1];
        if (result.isFinal) {
            console.log(result)
            MPP.chat.send(capitalizeFirstLetter(result[event.results.length - 1].transcript) + ".");
        }
    }
}

function handleKeyDown(evt) {
    var code = parseInt(evt.keyCode);
    if (code == 220) { //Yoshify's speech to text
        if (listening) {
            listening = false;
            Voice.stop();
            console.log('Speech to Text', 'Stopping Capture', 3000, '#midi-btn');
        } else {
            listening = true;
            Voice.start();
            console.log('Speech to Text', 'Listening (press again to send)', 3000, '#midi-btn');
        }
        //voi
    }
}
$(document).on("keydown", handleKeyDown)
