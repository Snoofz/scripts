// ==UserScript==
// @name         Dimentia Bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://mppclone.com/*
// @match        https://www.multiplayerpiano.org/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

let dimentia = [];

if (localStorage.dimentia) {
    dimentia = JSON.parse(localStorage.dimentia);
}

MPP.client.on("a", msg => {
    if (msg.p._id !== "2ffc3744fbc1bc6c6ef4a330" || msg.p._id !== "ead940199c7d9717e5149919" || msg.p._id !== MPP.client.getOwnParticipant()._id) return;
    dimentia.push(msg.a);
    localStorage.dimentia = JSON.stringify(dimentia);
});

const sendDimentia = function() {
    let time = Math.random() * 300000 + 30000
    console.log(time);
    setTimeout(() => {
        let r = dimentia[Math.floor(Math.random() * dimentia.length)];
        MPP.chat.send(r);
        sendDimentia();
    }, time);
}

sendDimentia();
