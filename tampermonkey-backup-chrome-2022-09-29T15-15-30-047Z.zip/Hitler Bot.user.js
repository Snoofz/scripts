// ==UserScript==
// @name         Hitler Bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://mpp.hri7566.info/*
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=hri7566.info
// @grant        none
// ==/UserScript==

let joinarr = [
    '&NAME walks in with a big smile. Unfortunately, their pants are unzipped.',
    '&NAME flies through the door, destroying the thriving weed farm. This is the third time this week...',
    '&NAME joins the club. Time to party!',
    '&NAME, the manager of this establishment, walks in swiftly with their briefcase.',
    '&NAME enters the building. Everyone, act natural. ',
    '&NAME smashes through a window on a out-of-control hose.',
    '&NAME waltzes into the room. Get it? Waltz? Because ... oh forget it.',
    '&NAME bursts thought the wall dressed as the Kool-Aid Man. "OH YEAH!!!"',
    '&NAME, you\'re late, get to work, slave.',
    "An axe breaks through the door. HERE'S &NAME!!!!",
    "&NAME rode into the room on a sinking ship.",
    "&NAME fell through the ceiling naked into the party. Everyone is stunned.",
    "&NAME popped out of someone's chest like an alien. That's okay, every kind is welcome here.",
    "&NAME blasts through the door and scans the room like Darth Vader."
];

let leavearr = [
    "&NAME left the server.",
    "&NAME jumped out the window and landed in the street.",
    "&NAME was Thanos-snapped out of existence.",
    "&NAME finished their work on the slave farm.",
    "&NAME puts on their hat and grabs their cane, then struts out the door.",
    "&NAME slithered into the darkness.",
    "&NAME's credits are rolling.",
    "&NAME Scooby Doo and Shaggy'd their way out of the room.",
    "&NAME is shot out of the ship like a photon torpedo.",
    "Before the house collapses, &NAME rushes their way out and speeds down the street"
]

setTimeout(() => {
    MPP.client.on("participant added", p => {
        MPP.client.sendArray([{m:"a", message:`\u034f${joinarr[Math.floor(Math.random()*joinarr.length)].split("&NAME").join(p.name).split("&CH").join(MPP.client.channel._id)}`}]);
    });

    MPP.client.on("participant removed", p => {
        MPP.client.sendArray([{m:"a", message:`\u034f${leavearr[Math.floor(Math.random()*leavearr.length)].split("&NAME").join(p.name).split("&CH").join(MPP.client.channel._id)}`}]);
    });
}, 5000);

class Command {
    constructor (cmd, usage, minargs, func, minrank, hidden) {
        this.cmd = cmd;
        this.usage = usage;
        this.minargs = minargs;
        this.func = func;
        this.minrank = minrank;
        this.hidden = hidden;
    }
}

const client = MPP.client;

client.on("a", () => {

});






















