// ==UserScript==
// @name         kill bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mppclone.com
// @grant        none
// ==/UserScript==

window.gClient = MPP.client;

let prefix = "😊";

function sendChat(...args) {
    gClient.sendArray([{
        m: 'a',
        message: `\u034f${args.join(' ')}`
    }]);
}

function getPart(str) {
    for (let p of Object.values(gClient.ppl)) {
        if (p.name.toLowerCase().includes(str.toLowerCase()) || p._id.toLowerCase().includes(str.toLowerCase())) {
            return p;
        }
    }
}

gClient.on("a", msg => {
    msg.args = msg.a.split(" ");
    msg.cmd = msg.args[0].substring(prefix.length).toLowerCase().trim();
    msg.argcat = msg.a.substring(msg.args[0].length).trim();

    if (!msg.a.startsWith(prefix)) return;

    switch (msg.cmd) {
        case "help":
            sendChat(`Commands: ${prefix}help | ${prefix}kill`);
            break;
        case "kill":
            let p = getPart(msg.argcat);
            if (!msg.args[1]) {
                p = msg.p;
            }
            if (p._id == msg.p._id) {
                sendChat(`In the ancient ritual of seppuku, ${msg.p.name} unsheaths their sword and runs it through their stomach.`);
                break;
            }

            sendChat(`${msg.p.name} killed ${p.name}.`);
            break;
        case "color":
            sendChat(`Your color is: ${new Color(msg.p.color).getName()} [${msg.p.color}]`);
            break;
    }
});
