// ==UserScript==
// @name         Name
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

let name = "๖ۣۜH͜r̬i͡7566";

setInterval(() => {
    if (MPP.client.getOwnParticipant().name !== name) {
        MPP.client.sendArray([{m:'userset', set:{name: name, color:"#ff2800"}}]);
    }
});
