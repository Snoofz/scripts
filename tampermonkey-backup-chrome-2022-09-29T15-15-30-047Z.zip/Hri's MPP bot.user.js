// ==UserScript==
// @name         Hri's MPP bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Uses object-oriented commands.
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// @require      https://cdnjs.cloudflare.com/ajax/libs/mathjs/6.6.5/math.min.js
// @require      https://www.multiplayerpiano.com/*
// ==/UserScript==

function replaceAt(string, index, replace) { //from bop it
    return string.substring(0, index) + replace + string.substring(index + 1);
}

var client = MPP.client; //from brandon

function chat(string) { //from everything i've ever made
    client.sendArray([{m:'a', message:"\u034f"+string}]);
}

function getPart(boop) { //from karl
    for (const id in client.ppl) {
        let part = client.ppl[id];
        if (part.name.toLowerCase().indexOf(boop.toLowerCase()) !== -1) {
            return part;
            break;
        } else if (part._id.indexOf(boop) !== -1) {
            return part;
        }
    }
}

var prefix = "^";
var cmds = [];
var lockdown = false;
var ownerid = client.getOwnParticipant()._id;
var ranks = {
    kings: ["5ce52c6017d5e600cc9e100a", "3d34d4352eca294aa727412c", "b8ae6fcda00bd61091787c05", "e47fcd47f8aa959ed0abbe83"],
    nobles: ["90b5a0bee7cfc3b32c252e0b", "17102e1973589cf17deddadd", "d9ad1be8a18a17e1d47703ec"],
    knights: [],
    banned: ["17102e1973589cf17deddadd"]
};

function addcmd(cmd, usage, minargs, func, minrank, hidden) {
    cmds.push({
        cmd:cmd,
        usage:usage,
        minargs:minargs,
        func:func,
        minrank:minrank,
        hidden:hidden
    });
}

function getUsage(cmd) {
    let found = cmds.find((command) => cmd == command.cmd);
    if (found) {
        return found.usage.replace("CMDCHAR", prefix);
    } else {
        return `There is no help for '${cmd}'.`;
    }
}

function getRank(user) {
    let found = getPart(user)._id;
    if (ranks.kings.indexOf(found) !== -1) {
        return "king";
    } else if (ranks.nobles.indexOf(found) !== -1) {
        return "noble";
    } else if (ranks.knights.indexOf(found) !== -1) {
        return "knight";
    } else if (ranks.banned.indexOf(found) !== -1) {
        return "banned";
    } else {
        return "peasant";
    }
}

function rankToNum(string) {
    switch (string) {
        case "banned":
            return -1;
            break;
        case "king":
            return 3;
            break;
        case "noble":
            return 2;
            break;
        case "knight":
            return 1;
            break;
        default:
            return 0;
            break;
    }
}

addcmd("help", `Usage: CMDCHARhelp`, 0, msg => {
    if (msg.args.length - 1 > 0) {
        chat(getUsage(msg.args[1]));
    } else {
        let tosend = `Commands:`;
        cmds.forEach((command) => {
            if (!command.hidden) {
                if (rankToNum(msg.rank) >= command.minrank) {
                    tosend += ` ${prefix}${command.cmd} | `;
                }
            }
        });
        tosend = tosend.trim();
        tosend = replaceAt(tosend, tosend.length - 1, "");
        chat(tosend);
    }
}, 0, false);

addcmd("ping", `Usage: CMDCHARping`, 0, msg => {
    chat("Pong!");
}, 0, false);

addcmd("id", `Usage: CMDCHARid`, 0, msg => {
    if (msg.args[1]) {
        let p = getPart(msg.argcat);
        if (p) {
            chat(p.name + "'s _id: " + p._id + " | Color: " + p.color);
        } else {
            chat("That's not a person.");
        }
    } else {
        chat("Your _id is: " + msg.p._id + " | Color: " + msg.p.color);
    }
}, 0, false);

addcmd("rank", `Usage CMDCHARrank <user (opt)>`, 0, msg => {
    if (!msg.args[1]) {
        chat("Ranks are used to determine who is able to use certain commands, and they're split into four categories: Kings > Nobles > Knights > Peasants. ");
        chat(msg.p.name + ", you're a " + msg.rank + ".");
    } else {
        found = getPart(msg.args[1]);
        if (found) {
            chat(found.name + "'s rank is a " + getRank(found._id) + ".");
        } else {
            chat(`The user '${msg.args[1]}' couldn't be found. Try using part of their username or id.`);
        }
    }
}, 0, false);

addcmd("8ball", `Usage: CMDCHAR8ball <polar quesiton>`, 1, msg => {
    chat(Ball[Math.floor(Math.random()*Ball.length)] + ", " + msg.p.name);
}, 0, false);

addcmd("prefix", `Usage: CMDCHARprefix <new prefix>`, 1, msg => {
    prefix = msg.args[1];
    chat(`The prefix was changed to '${prefix}'.`);
}, 2, false);

addcmd("about", `Usage: CMDCHARabout`, 0, msg => {
    chat("This bot was made by Hri7566. It has been ported to tampermonkey after the great glitch disaster of 2020. Currently, there is a port of this bot on Discord written in C#.");
}, 0, false);

addcmd("js", `Usage: CMDCHARjs <eval statement>`, 1, msg => {
    let i = msg.a.substring(msg.a.split(" ")[0].length + 1);
    try {
        chat("Console: " + eval(i.toString()));
    } catch (e) {
        chat(e + ".");
    }
}, 3, false);

addcmd("punch", `Usage: CMDCHARpunch <user>`, 1, msg => {
    let p = getPart(msg.argcat);
    if (p) {
        chat(`${msg.p.name} punched ${p.name}. ` + reason[Math.floor(Math.random()*reason.length)]);
    } else {
        chat(`'${msg.argcat}' isn't a user.`);
    }
}, 0, false);

addcmd("kill", `Usage: CMDCHARkill <user>`, 1, msg => {
    let p = getPart(msg.argcat);
    if (p) {
        if (p._id == msg.p._id) {
            var NAME = msg.p.name;
            var Suicide = [
                "In the ancient ritual of seppuku, " + NAME + " unsheaths their sword and runs it though their stomach.",
                NAME + " committed toaster-bath.",
                NAME + " shot themselves.",
                NAME + " injected themselves with the coronavirus.",
                NAME + " electrocuted themselves.",
                "Due to a war in Saigon, " + NAME + " burned themselves to death like a Buddhist monk.",
                NAME + " jumped off the roof.",
                NAME + " took cyanide.",
                NAME + " took the easy way out.",
                NAME + " overdosed on drugs.",
                NAME + " left their car on in the garage.",
                "Following the practices that started in Mesoamerica, " + NAME + " performed self-decapitation with an obisidan axe.",
                NAME + " chained an anvil to their foot and drowned themselves.",
                NAME + " splattered their own brains across the street.",
                NAME + " jumped off of a bridge.",
                NAME + " went skydiving without their parachute.",
                NAME + " stuck nails in their own eyes and bled to death.",
                NAME + " died while having surgery.",
                NAME + " sliced themselves in half with a buzzsaw. Their reproductive organs will be donated to the nearest Chuck E. Cheese.",
                NAME + " starved to death.",
                NAME + " crashed their car into someone's living room while assuming a 69 sex position with their cousin while 27.5 times over the legal alcohol limit. A 22-inch dildo, anal beads, a bible, a crack pipe, and meth were found at the scene."
            ];
            chat(Suicide[Math.floor(Math.random() * Suicide.length)]);
        } else {
            chat(`${msg.p.name} killed ${p.name} with ${object[Math.floor(Math.random()*object.length)]}. ` + reason[Math.floor(Math.random()*reason.length)]);
        }
    } else {
        chat(`'${msg.argcat}' isn't a user.`);
    }
}, 0, false);

addcmd("slap", `Usage: CMDCHARslap <user>`, 1, msg=> {
    let p = getPart(msg.argcat);
    if (p) {
        if (p._id == msg.p._id) {
            chat(`${msg.p.name} slapped themselves.`);
        } else {
            chat(`${msg.p.name} slapped ${p.name} with ${object[Math.floor(Math.random()*object.length)]}. ` + reason[Math.floor(Math.random()*reason.length)]);
        }
    } else {
        chat(`'${msg.argcat}' isn't a user.`);
    }
}, 0, false);

addcmd("ban", `Usage: CMDCHARban <user>`, 1, msg => {
    let p = getPart(msg.argcat);
    if (p) {
        if (ranks.banned.indexOf(p._id) !== -1) {
            chat(p.name + " is already banned, you fucking idiot.");
        } else {
            ranks.banned.push(p._id);
            chat(p.name + " was banned. " + Banmsg[Math.floor(Math.random()*Banmsg.length)]);
        }
    }
}, 2, false);

addcmd("pardon", `Usage: CMDCHARpardon <user>`, 1, msg => {
    let p = getPart(msg.argcat);
    if (p) {
        if (ranks.banned.indexOf(p._id) == "-1") {
            chat("What are you fucking dumb? That user isn't banned.");
        } else {
            ranks.banned.splice(ranks.banned.indexOf(p._id));
            chat(p.name + " was unbanned. Lucky.");
        }
    } else {
        chat(`'${msg.argcat}' isn't a user.`);
    }
}, 2, false);

addcmd("lockdown", `Usage: CMDCHARlockdown`, 0, msg => {
    if (lockdown == false) {
        lockdown = true;
        chat("Lockdown initiated. Unless you have a high rank, no commands can be accessed.");
    } else {
        lockdown = false;
        chat("Lockdown retracted. All commands are available.");
    }
}, 2, false);

addcmd("kings+", `Usage: CMDCHARkings+ <user>`, 1, msg => {
    let p = getPart(msg.argcat);
    if (p) {
        if (ranks.kings.indexOf(p._id) !== -1) {
            chat(p.name + " is already a king.");
        } else {
            ranks.kings.push(p._id);
            chat(p.name + " is now a king. Lucky bastard.");
        }
    } else {
        chat("Whatever the fuck abomination you put in isn't a person.");
    }
}, 3, false);

addcmd("nobles+", `Usage: CMDCHARnobles+ <user>`, 1, msg => {
    let p = getPart(msg.argcat);
    if (p) {
        if (ranks.nobles.indexOf(p._id) !== -1) {
            chat(p.name + " is already a noble.");
        } else {
            ranks.nobles.push(p._id);
            chat(p.name + " is now a noble.");
        }
    } else {
        chat("Whatever the fuck abomination you put in isn't a person.");
    }
}, 3, false);

addcmd("knights+", `Usage: CMDCHARknights+`, 1, msg => {
    let p = getPart(msg.argcat);
    if (p) {
        if (ranks.knights.indexOf(p._id) !== -1) {
            chat(p.name + " is already a knight.");
        } else {
            chat(p.name + " is now a knight.");
            ranks.knights.push(p._id);
        }
    } else {
        chat("Whatever the fuck abomination you put in isn't a person.");
    }
}, 2, false);

addcmd("kings-", `Usage: CMDCHARkings-`, 1, msg => {
    let p = getPart(msg.argcat);
    if (p._id == ownerid) {
        chat("You can't change the rank of the owner.");
        return;
    }
    if (p) {
        if (ranks.kings.indexOf(p._id) !== -1) {
            chat(p.name + " is no longer a king.");
            ranks.kings.splice(ranks.kings.indexOf(p._id));
        } else {
            chat(p.name + " isn't a king, you dumb bastard.");
        }
    } else {
        chat("Whatever the fuck abomination you put in isn't a person.");
    }
}, 3, false);

addcmd("nobles-", `Usage: CMDCHARnobles-`, 1, msg => {
    let p = getPart(msg.argcat);
    if (p) {
        if (ranks.nobles.indexOf(p._id) !== -1) {
            chat(p.name + " is no longer a noble.");
            ranks.nobles.splice(ranks.nobles.indexOf(p._id));
        } else {
            chat(p.name + " isn't a noble.");
        }
    } else {
        chat("Whatever the fuck abomination you put in isn't a person.");
    }
}, 3, false);

addcmd("knights-", `Usage: CMDCHARknights-`, 1, msg => {
    let p = getPart(msg.argcat);
    if (p) {
        if (ranks.knights.indexOf(p._id) !== -1) {
            chat(p.name + " is no longer a knight.");
            ranks.knights.splice(ranks.knights.indexOf(p._id));
        } else {
            chat(p.name + " isn't a knight.");
        }
    } else {
        chat("Whatever the fuck abomination you put in isn't a person.");
    }
}, 2, false);

addcmd("string", `Usage: CMDCHARstring <evaluation>`, 1, msg =>{
    try {
        chat(`Answer: ${math.eval(msg.argcat)}`);
    } catch (err) {
        chat("Invalid usage.");
    }
}, 0, false);

client.on('a', msg => {
    msg.args = msg.a.split(' ');
    msg.input = n => msg.args.slice(n).join(" ");
    msg.cmd = msg.args[0].split(prefix).slice(1).join(prefix);
    msg.argcat = msg.a.substring(msg.cmd.length + 1).trim();
    msg.rank = getRank(msg.p._id);

    if ((lockdown == false) || (rankToNum(msg.rank) >= 2)) {
        if (msg.rank !== "banned") {
            if (msg.a == "Hello there") {
                chat("General Kenobi!");
            }
            if (msg.a.substring(prefix.length) == "help") {
                if (!msg.a.startsWith(prefix)) {
                    chat(`The prefix is ${prefix}, ${msg.p.name}.`);
                }
            }
            cmds.forEach((commandobj) => {
                if (!msg.a.substring(prefix.length).startsWith(prefix))
                    switch (msg.cmd) {
                        case commandobj.cmd: {
                            if (rankToNum(msg.rank) >= commandobj.minrank) {
                                if ((msg.args.length - 1) < commandobj.minargs) {
                                    chat(getUsage(msg.cmd));
                                } else {
                                    if (!msg.a.startsWith(prefix)) {
                                        chat(`The prefix is '${prefix}'.`); return;
                                    } else {
                                        commandobj.func(msg);
                                    }
                                }
                            }
                            break;
                        }
                    }
            });
        }
    }
});

var Ball = [
    "It is certain",
    "It is decidedly so",
    "Without a doubt",
    "Yes - definitely",
    "You may rely on it",
    "As I see it, yes",
    "Most likely",
    "Outlook good",
    "Yes",
    "Signs point to yes",
    "Reply hazy, try again",
    "Ask again later",
    "Better not tell you now",
    "Cannot predict now",
    "Concentrate and ask again",
    "Don't count on it",
    "My reply is no",
    "My sources say no",
    "Outlook not so good",
    "Very doubtful"
];

var Banmsg = [
    "What an idiot.",
    "Fucking idiot.",
    "What the hell, man?",
    "The ban hammer has spoken!",
    "What the hell?",
    "What the fuck?",
    "What an asshole.",
    "Fucking asshole.",
    "What a dumbass.",
    "Rated E for idiot.",
    "Fucking retard.",
    "Come the fuck on, dude.",
    "Dickhead.",
    "Frickin' idiot.",
    "I can't believe I'm surrounded by frickin' idiots!",
    "Dumbass.",
    "You fucking dumbass.",
    "Who's next?",
    "What a retard.",
    "This doesn't happen often.",
    "What a dumb bitch.",
    "Y u so stupiht, stupiht?",
    "Fucking retard.",
    "Yeah, you heard me right.",
    "Yeah, get the fuck out of here!",
    "Rest in pieces.",
    "That's right.",
    "Stupid bitch."
];

var reason = [
    "They didn't see it coming.",
    "They stole their oreos.",
    "They threatened them.",
    "They deserved it.",
    "They scared them.",
    "This is only the beginning.",
    "They tried to choke them.",
    "They've met with a terrible fate, haven't they?",
    "It was in the cooking recipe.",
    "They followed the youtube tutorial wrong.",
    "They are now on the FBI watchlist.",
    "They ate the yellow crayons.",
    "They hurt Karl's computer.",
    "They asked for it.",
    "They were caught masturbating in the toolshed",
    "They were acting stupid."
];

var object = ["a baseball","a lemon","a rolling pin","a bell","a rock","a spring","a twister","a street light","a fish","chocolate","a canvas","a basketball","a pasta strainer","an empty bottle","a tube of lip balm","a box of tissues","a can of chili","an egg beater","a wallet","scotch tape","a container of pudding","a rubber chicken","a mirror","a dog","a book","a balloon","a fan","a plush rabbit","an apple","a handful of change","a sofa","their purse","whatever was in their hand","a pickle","nail clippers","scissors","a bottle","broccoli","a desk","a whistle","a cookie","a map","a nail","a cowboy hat","a candy bar","a stop sign"];





















