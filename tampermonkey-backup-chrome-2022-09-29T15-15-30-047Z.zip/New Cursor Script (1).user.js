// ==UserScript==
// @name         New Cursor Script
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  f(x) cursor
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

var client = MPP.client;

var pos = {x: 0, y: 0};
var vel = {x: 2/5, y: 2/7};

var cursor = setInterval(function() {
    if (pos.x > 100) pos.x = 0;
    pos.x += vel.x;
    pos.y = Math.sin(pos.x/2) * 5;
}, 25);

var cursormath = setInterval(function() {
    client.sendArray([{m:'m', x:pos.x, y:pos.y + 50}]);
}, 25);