// ==UserScript==
// @name         ESBuild
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://mpp.hri7566.info/*
// @match        https://mppclone.com/*
// @match        https://www.multiplayerpiano.org/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=hri7566.info
// @grant        none
// @require      file:///Z:/mpp-script/out.js
// ==/UserScript==