// ==UserScript==
// @name         Hri's Rainbow
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://mpp176.tk/*
// @icon         https://www.google.com/s2/favicons?domain=hri7566.info
// @grant        none
// ==/UserScript==

function hslToHex(h, s, l) {
  l /= 100;
  const a = s * Math.min(l, 1 - l) / 100;
  const f = n => {
    const k = (n + h / 30) % 12;
    const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color).toString(16).padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

let h = Math.floor(Math.random() * 360);
let s = 50;
let l = 50;

let hvel = 5;
let svel = 1;
let lvel = 0.5;

window.rainbow = setInterval(() => {
    hvel = Math.floor(Math.random()*10);
    h += hvel;
    if (h > 360) h = 0;

    s += svel;
    if (s >= 100 || s <= 50) {
        svel = -svel;
    }

    l += lvel;
    if (l >= 75 || l <= 25) {
        lvel = -lvel;
    }

    //MPP.client.sendArray([{m:"admin message", password:"secretfuckingpasswordbitchLOL", msg:{m:"color", _id: MPP.client.getOwnParticipant()._id, color: hslToHex(h, s, l)}}])
    MPP.client.sendArray([{m: "userset", set:{color: hslToHex(h, s, l)}}]);
}, 50);
