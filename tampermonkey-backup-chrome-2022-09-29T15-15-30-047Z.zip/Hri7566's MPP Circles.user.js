// ==UserScript==
// @name         Hri7566's MPP Circles
// @namespace    https://www.multiplayerpiano.com/
// @version      0.1
// @description  script for multiplayer piano
// @author       Hri7566
// @match        https://mppclone.com/*
// @grant        none
// ==/UserScript==

$("body").prepend("<canvas id=\"circles\" style=\"position: absolute;\">");

window.canvas = document.querySelector('#circles');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var c = canvas.getContext('2d');
var grd = c.createRadialGradient(0, 0, 0, innerWidth, innerHeight, 360);
grd.addColorStop(.167, "red");
grd.addColorStop(.336, "yellow");
grd.addColorStop(.5, "green");
grd.addColorStop(.667, "blue");
grd.addColorStop(.833, "purple");
grd.addColorStop(1, "red");

var mouse = {
    x: undefined,
    y: undefined
}

window.addEventListener('mousemove', function(event) {
    mouse.x = event.x;
    mouse.y = event.y;
});

var Circle = function (x, y, vx, vy, r) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.r = r;

    this.draw = function() {
        c.beginPath()
        c.lineWidth = 5;
        c.arc(this.x, this.y, this.r, 0, Math.PI * 2, false);
        c.strokeStyle = grd;
        c.stroke();
        c.fillStyle = grd;
        c.fill();
    }

    this.update = function() {
        if ((this.x + this.r > innerWidth) || (this.x - this.r < 0)) {
            this.vx = -this.vx;
        }
        if ((this.y + this.r > innerHeight) || (this.y - this.r < 0)) {
            this.vy = -this.vy;
        }
        this.x += this.vx;
        this.y += this.vy;

        if ((mouse.x - this.x < 50) && (mouse.x - this.x > -50) && (mouse.y - this.y < 50 && mouse.y - this.y > -50) && (this.r < 50)) {
            this.r += 10;
            if (this.r > 50) {
                this.r = 50;
            }
        } else if (this.r > 0) {
            this.r -= 1;
        }

        this.draw()
    }
}

var circleArray = [];

for (var i = 0; i < 2000; i++) {
    var x = Math.random() * innerWidth;
    var y = Math.random() * innerHeight;
    var vx = (Math.random() - 0.5) * 8;
    var vy = (Math.random() - 0.5) * 8;
    var r = 0;
    circleArray.push(new Circle(x, y, vx, vy, r));
}

function animate() {
    requestAnimationFrame(animate);
    c.clearRect(0, 0, innerWidth, innerHeight);
    for (var i = 0; i < circleArray.length; i++) {
        circleArray[i].update();
    }
}

animate()


