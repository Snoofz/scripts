// ==UserScript==
// @name         Template Bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  MPP Bot template
// @author       Hri7566
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

var prefix = "!";

MPP.client.on("a", function(msg) {
    // basic array and string stuff
    let args = msg.a.split(" ");
    let cmd = args[0].split(prefix).join(''); // get the command the user typed

    if (!msg.a.startsWith(prefix)) return; // test for prefix

    switch (cmd) {
        case 'help':
        case 'h':
            sendChat(`Commands: ${prefix}help, ${prefix}about, ${prefix}8ball`);
            break;
        case 'about':
            sendChat('This is a template bot by Hri7566.');
            break;
        case '8ball':
            // msg.p.name is the user's name
            sendChat(magic8ball() + msg.p.name + '.')
            break;
    }
});

function sendChat(str) {
    MPP.client.sendArray([{m:"a", message: str}]); // send the message in chat
}

function magic8ball() {
    return magic8ballanswers[Math.floor(Math.random() * magic8ballanswers.length)]; // get a random answer from the array below
}

var magic8ballanswers = [ // this is an array
    "As I see it, yes",
    "Ask again later",
    "Better not tell you now",
    "Cannot predict now",
    "Concentrate and ask again",
    "Don't count on it",
    "It is certain",
    "It is decidedly so",
    "Most likely",
    "My reply is no",
    "My sources say no",
    "Outlook not so good",
    "Outlook good",
    "Reply hazy, try again",
    "Signs point to yes",
    "Very doubtful",
    "Without a doubt",
    "Yes",
    "Yes - definitely",
    "You may rely on it"
];
