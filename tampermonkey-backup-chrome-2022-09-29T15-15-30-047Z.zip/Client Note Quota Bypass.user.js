// ==UserScript==
// @name         Client Note Quota Bypass
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @match        https://mpp.terrium.net/*
// @match        https://piano.ourworldofpixels.com/*
// @grant        none
// ==/UserScript==

setTimeout(function() {
    setInterval(function() {
        MPP.noteQuota.points = Infinity;
    }, 1000);
}, 2000);