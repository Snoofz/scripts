// ==UserScript==
// @name         Join/Leave Log
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://*.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

$("#chat").css("width", "50%");

$("head").append(`<style>


#chat2 { opacity: 1; position: fixed; bottom: 64px; right: 0; width: 50%; vertical-align: bottom; font-size: 13px; color: white; text-shadow: #888 1px 1px; }
#chat2, #chat2 * { user-select: text; -webkit-user-select: text; -moz-user-select: text; -ms-user-select: text; }
#chat2 ul { list-style: none; margin: 4px; padding: 0; background-attachment: local; }
#chat2 li { padding: 2px; opacity: 1; }
#chat2 li .name { font-weight: bold; margin-right: 10px; }
#chat2 li .message { margin-right: 6px; }
#chat2 li .quote { color: #789922; }
#chat2 input { margin: 4px; width: 99%; border: 1px solid #fff; background: none; text-shadow: #888 1px 1px; color: #fff;
	border-radius: 4px; -webkit-border-radius: 4px; -moz-border-radius: 4px; }
#chat2 input::-webkit-input-placeholder { color: #ccc; }
#chat2 input:-moz-placeholder { color: #ccc; }
#chat2 input:focus { outline: none; border: 1px solid #ff8; }
#chat2.chatting { background: rgba(64,80,80,0.75); border-radius: 5px; box-shadow: 1px 1px 5px #888; transition: all 0.1s; }
#chat2.chatting li { display: list-item !important; opacity: 1 !important; text-shadow: #aaa 1px 1px; }
#chat2.chatting ul { max-height: 50em; overflow-y: scroll; overflow-x: hidden; word-wrap: break-word; }

</style>`);

$("#chat").after(() => {
    return `


<div id="chat2">
    <ul></ul>
</div>


    `;
});

MPP.client.on("participant added", p => {
    $("#chat2 ul").append(`<li style="color: ${p.color}; opacity: 1;"><span class="message">${p._id} | ${p.name} joined.</span></li>`);
});

MPP.client.on("participant removed", p => {
    $("#chat2 ul").append(`<li style="color: ${p.color}; opacity: 1;"><span class="message">${p._id} | ${p.name} left.</span></li>`);
});

