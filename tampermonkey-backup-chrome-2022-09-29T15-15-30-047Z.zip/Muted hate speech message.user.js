// ==UserScript==
// @name         Muted hate speech message
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  die forever piano bastard i hate you
// @author       Hri7566
// @match        https://mppclone.com/*
// @match        https://multiplayerpiano.com/*
// @match        https://www.multiplayerpiano.org/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mppclone.com
// @grant        none
// @copyright    2022+
// ==/UserScript==

MPP.client.on('a', msg => {
    if (msg.a.toLowerCase().includes("muted")) {
        MPP.client.sendArray([{
            m: 'a',
            message: `you saying "muted" doesn't mean shit, die forever bastard`
        }]);
    }
});
