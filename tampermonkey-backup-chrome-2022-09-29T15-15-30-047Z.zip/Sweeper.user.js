// ==UserScript==
// @name         Sweeper
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @match        https://www.multiplayerpiano.net/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// @require      file:///D:\Sweeper\dist\bot.user.js
// @grant        GM_addStyle
// ==/UserScript==

// $(document).unbind("mousemove");
