// ==UserScript==
// @name         Note Deficit (Broken)
// @namespace    https://hri7566.info
// @version      1.0.0
// @description  Note Deficit for Multiplayer Piano
// @author       Hri7566
// @match        https://mppclone.com/*
// @match        https://www.multiplayerpiano.org/*
// @match        https://multiplayerpiano.com/*
// @match        https://mpp.terrium.net/*
// @match        https://piano.ourworldofpixels.net/*
// @match        http*://augustberchelmann.com/piano/*
// @match        https://www.multiplayerpiano.dev/*
// @match        https://mpp.hri7566.info/*
// @match        https://mpp.autoplayer.space/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mppclone.com
// @grant        none
// ==/UserScript==

let myNotes = 0;
let otherNotes = 0;

$("body").append(`<div id="note-deficit"></div>`);
$("#note-deficit").css({
    position: "absolute",
    right: "50px",
    bottom: "100px"
});

let updateDeficit = () => {
    let notes = myNotes - otherNotes;
    let color = "green";
    if (notes < 0) {
        color = "red";
    } else {
        notes = `+${notes}`;
    }
    $("#note-deficit").text(notes);
    $("#note-deficit").css("color", color);
}

updateDeficit();

MPP.client.on("n", (msg) => {
    otherNotes += msg.n.length;
    updateDeficit();
});

MPP.client.startNote = (...args) => {
    myNotes++;
    updateDeficit();
    if(typeof note!=='string')return;if(MPP.client.isConnected()){var vel=typeof vel==="undefined"?undefined:+vel.toFixed(3);if(!MPP.client.noteBufferTime){MPP.client.noteBufferTime=Date.now();MPP.client.noteBuffer.push({n:note,v:vel});}else{MPP.client.noteBuffer.push({d:Date.now()-MPP.client.noteBufferTime,n:note,v:vel});}}
}
