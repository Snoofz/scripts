// ==UserScript==
// @name         Note Quota Bypass
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

MPP.client.on("hi", () => {
    setInterval(() => {MPP.noteQuota.points = Infinity;});
});