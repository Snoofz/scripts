// ==UserScript==
// @name         Trick Bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

window.client = MPP.client;

let prefix = "$";
let cmds = [];

let ranks = {
    owner: [client.getOwnParticipant()._id],
    admin: [],
    banned: []
};

function getRank(p) {
    if (ranks.owner.indexOf(p._id) !== -1) {
        return {name: "Owner", _id: 2};
    } else if (ranks.admin.indexOf(p._id) !== -1) {
        return {name: "Admin", _id: 1};
    } else if (ranks.banned.indexOf(p._id) !== -1) {
        return {name: "Banned", _id: -1};
    } else {
        return {name: "None", _id: 0};
    }
}

let sendChat = (str) => {
    client.sendArray([{m:'a', message:`\u034f${str}`}]);
};

let addCommand = (cmd, usage, minargs, func, minrank, hidden) => {
    cmds.push({cmd: typeof(cmd) == 'string' ? [cmd] : cmd, usage: usage, minargs: minargs, func: func, minrank: minrank, hidden: hidden});
};

let getUsage = (str) => {
    return str.split("PREFIX").join(prefix);
}

addCommand("help", `Usage: PREFIXhelp`, 0, msg => {
    let out;
    if (!msg.args[1]) {
        out = `Commands: `;
        cmds.forEach(cmd => {
            if (!cmd.hidden) {
                out += ` ${prefix}${cmd.cmd[0]} | `;
            }
        });
        out = out.substring(0, out.length - 2);
        out = out.trim();
        return out;
    } else {
        out = `There is no help for '${msg.argcat}'.`;
        cmds.forEach(cmd => {
            cmd.cmd.forEach(c => {
                if (msg.argcat == c) {
                    if (typeof(msg.args[1]) == 'string') {
                        out = getUsage(cmd.usage);
                    }
                }
            });
        });
        return out;
    }
}, 0, false);

addCommand("about", `Usage: PREFIXabout`, 0, msg => {
    return `This bot was totally not made by Hri7566.`;
}, 0, false);

client.on('a', msg => {
    msg.args = msg.a.split(' ');
    msg.cmd = msg.args[0].split(prefix).join("");
    msg.argcat = msg.a.substring(prefix.length + msg.cmd.length).trim();
    msg.p.rank = getRank(msg.p);

    cmds.forEach(cmd => {
        if (msg.p.rank._id < 0) {
            return;
        }
        cmd.cmd.forEach(c => {
            console.log('start');
            if (msg.cmd.toLowerCase() == c.toLowerCase()) {
                console.log('found command');
                if (msg.p.rank._id >= cmd.minrank) {
                    console.log('has right rank');
                    console.log(msg.args.length - 1);
                    console.log(cmd.minargs);
                    if (msg.args.length - 1 >= cmd.minargs) {
                        console.log('has right args, running');
                        let out = cmd.func(msg);
                        console.log(out);
                        if (typeof(out) == "string") {
                            if (out.length > 0) {
                                console.log('out is good string, sending in chat')
                                sendChat(out);
                            }
                        }
                    } else {
                        console.log('does not have right args');
                    }
                } else {
                    console.log('does not have right rank');
                }
            }
        });
    });
});




