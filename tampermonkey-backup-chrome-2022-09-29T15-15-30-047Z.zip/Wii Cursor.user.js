// ==UserScript==
// @name         Wii Cursor
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Wii cursor for MPP
// @author       Hri7566
// @match        https://mppclone.com/*
// @match        https://multiplayerpiano.com/*
// @match        https://www.multiplayerpiano.org/*
// @match        https://mpp.hri7566.info/*
// @match        https://mppkinda.com/*
// @match        https://www.multiplayerpiano.dev/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mppclone.com
// @grant        none
// ==/UserScript==

$("body").css("cursor", "url(https://rc24.xyz/images/cursors/wii.cur),default");
$(".ugly-button, .notification .x, li.connection").css("cursor", "url(https://rc24.xyz/images/cursors/wii-hover.cur),pointer");
