// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://localhost/*
// @icon         https://www.google.com/s2/favicons?domain=undefined.localhost
// @grant        none
// ==/UserScript==

MPP.client.ws.addEventListener("message", (evt) => {
    let msg = JSON.parse(evt.data)[0];

    if (msg.m == 'm') return;
    console.log(msg);
});