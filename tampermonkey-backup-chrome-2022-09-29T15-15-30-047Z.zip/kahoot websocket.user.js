// ==UserScript==
// @name         kahoot websocket
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://kahoot.it/*
// @icon         https://www.google.com/s2/favicons?domain=kahoot.it
// @grant        none
// ==/UserScript==

let oldws = WebSocket;

window.WebSocket = class extends oldws {
    constructor (uri) {
        super(uri);
        globalThis.ws = this;
    }
}
