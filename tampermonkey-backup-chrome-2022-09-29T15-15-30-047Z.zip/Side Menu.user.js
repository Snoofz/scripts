// ==UserScript==
// @name         Side Menu
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  A side menu for multiplayer piano
// @author       Hri7566
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

let enabled = false;

$("body").prepend(`<div id="side-menu"></div>`)

$("#side-menu").css({
    width: 0,
    "z-index": 9999,
    right: 0,
    transition: "width .1s ease-in-out",
    height: "100vh",
    display: "block",
    "box-sizing": "inherit",
    position: "absolute",
    background: "#111",
    "backdrop-filter": "blur(2px)",
    "border-left": "1px solid #444"
})

$("#bottom .relative").append(`
<div id="side-menu-btn" class="ugly-button">Side Menu</div>
`);

$("#side-menu-btn").css({
    position: "absolute",
    right: 212,
    top: 4
});

$("#side-menu-btn").on("click", evtn => {
    if (!enabled)
        $("#side-menu").css("width", 200),
            enabled = true;
    else
        $("#side-menu").css("width", 0),
            enabled = false;
});
