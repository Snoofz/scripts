// ==UserScript==
// @name         Log Messages
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

MPP.client.ws.addEventListener("message", async evt => {
    if (typeof(evt.data) == 'object') {
        console.log(await evt.data.text());
    } else {
        console.log(evt.data);
    }
});
