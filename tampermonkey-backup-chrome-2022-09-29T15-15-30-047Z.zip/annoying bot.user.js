// ==UserScript==
// @name         annoying bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

console.log("you have annoying bot on");

let cmds = [];

class Command {
    constructor(acc, usage, desc, minargs, cb, minrank, isHidden) {
        this.acc = acc;
        this.usage = usage;
        this.desc = desc;
        this.minargs = minargs;
        this.cb = cb;
        this.minrank = minrank;
        this.isHidden = isHidden;
    }

    static getUsage(str, p) {
        return str.split("%P").join(p);
    }
}


