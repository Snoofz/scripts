// ==UserScript==
// @name         Qhy Autominer
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

let client = MPP.client;

function genRandomTime() {
    let rando = Math.floor(Math.random()*30000);
    return rando + 1500;
}

client.on('a', msg => {
    if (msg.p.name.includes("qhy!help")) {
        if (msg.a.split('\u034f').join('').includes(`${client.getOwnParticipant().name}, ͏уоu'vе gоt`.split('\u034f').join(''))) {
            let time = genRandomTime();
            setTimeout(() => {
                client.sendArray([{m:'a', message: time % 2 == 0 ? 'qhy!dig' : 'qhy!mine'}]);
            }, time);
        }
        if (msg.a.toLowerCase().includes("restart") || msg.a.toLowerCase().includes("connected")) {
            let time = genRandomTime();
            setTimeout(() => {
                client.sendArray([{m:'a', message: time % 2 == 0 ? 'qhy!dig' : 'qhy!mine'}]);
            }, time);
        }
    }
});
