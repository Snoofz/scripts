// ==UserScript==
// @name         jaco remover
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://multiplayerpiano.com/*
// @icon         https://www.google.com/s2/favicons?domain=multiplayerpiano.com
// @grant        none
// ==/UserScript==

$("body a").remove();

setInterval(() => {
    $(".ad1").remove();
}, 250);
