// ==UserScript==
// @name         MPP.net Admin Features
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.net/*
// @match        https://www.multiplayerpiano.dev/*
// @grant        none
// ==/UserScript==

let password = "123123sucks";

adminChat = (string) => {
    MPP.client.sendArray([{
        m:'admin message',
        password:password,
        msg: {
            m:'eval',
            str: `this.rooms.get("${MPP.client.channel._id}").chat({participantId:""}, {p:{name:"mpp", color:"#ffffff",_id:"0",id:"0"}, message:"${string}"})`
        }
    }])
}

adminJS = (string) => {
if (typeof(string) !== 'string') string = string.toString();
MPP.client.sendArray([{m: "admin message", password: password, msg: {
				"m": "notification",
				"id":"js",
				"targetUser": "room",
				"target": "#names",
				"duration": 1,
				"class":"short",
				"html": `<script>${string.substring(string.indexOf("{")).substr(1, string.substring(string.indexOf("{")).length - 2)}</script>`
}}]);
}

adminHTML = (string, dur, target) => {
    MPP.client.sendArray([{m: "admin message", password: password, msg: {
				"m": "notification",
				"id":"js",
				"targetUser": "room",
				"target": target || "#piano",
				"duration": dur || 7000,
				"class":"short",
				"html": string
    }}]);
}

adminChownJS = () => {
let id = MPP.client.getOwnParticipant().id;
MPP.client.sendArray([{m: "admin message", password: password, msg: {
				"m": "notification",
				"id":"ebsprite",
				"targetUser": "room",
				"target": "#names",
				"duration": 1,
				"class":"short",
				"html": `<script>
MPP.client.sendArray([{m:'chown', id:'${id}'}]);
</script>`
			}}]);
}

adminChown = () => {
let id = MPP.client.getOwnParticipant().id;
MPP.client.sendArray([{m: "admin message", password: password, msg: {
				m:"chown",
    id:id
			}}]);
}

adminColor = (str, id) => {
MPP.client.sendArray([{m: "admin message", password: password, msg: {
				"m": "color",
				"_id":id || MPP.client.getOwnParticipant()._id,
				"color": str
			}}]);
}

getUser = i => {
    let out;
    for (let id in MPP.client.ppl) {
        let p = MPP.client.ppl[id];

        if (p._id.toLowerCase().includes(i.toLowerCase())) {
            out = p;
        }
    }
    return out;
}

adminRainbow = (id) => {

let p = getUser(id);

MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "7000",
        "class":"short",
        "html": `
<script>
if (!MPP.client.ppl["${p.id}"].nameDiv.classList.contains("rainbow-bg")) {
    MPP.client.ppl["${p.id}"].nameDiv.classList.add("rainbow-bg");
}
</script>
`
    }}]);

MPP.client.on("participant added", p => {


    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": p._id,
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
if (!MPP.client.ppl["${p.id}"].nameDiv.classList.contains("rainbow-bg")) {
    MPP.client.ppl["${p.id}"].nameDiv.classList.add("rainbow-bg");
}
</script>
`
    }}]);



});

}


adminSpin = () => {
    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
if (!MPP.piano.rootElement.classList.contains("spin")) {
    MPP.piano.rootElement.classList.add("spin");
}
</script>
`
    }}]);

MPP.client.on("participant added", p => {


    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": p._id,
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
if (!MPP.piano.rootElement.classList.contains("spin")) {
    MPP.piano.rootElement.classList.add("spin");
}
</script>
`
    }}]);



});
}


adminUnspin = () => {
    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
if (MPP.piano.rootElement.classList.contains("spin")) {
    MPP.piano.rootElement.classList.remove("spin");
}
</script>
`
    }}]);

MPP.client.on("participant added", p => {


    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": p._id,
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
if (MPP.piano.rootElement.classList.contains("spin")) {
    MPP.piano.rootElement.classList.remove("spin");
}
</script>
`
    }}]);



});
}

adminCrownRain = () => {
    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>

function crownFall() {
    let pos = Math.random() * 100;
    let jqcrown = $('<div id="crown"></div>').appendTo(document.body);
    jqcrown.addClass("spin");
    jqcrown.css({"left": pos + "%", "top": -10 + "%", "z-index": "-100"});
    jqcrown.animate({"left": pos + "%", "top": 100 + "%"}, 4000, "linear", function() {
        jqcrown.remove();
    });
}

crownInterval = setInterval(() => setTimeout(crownFall, Math.random() * 1000), 500);
</script>
`
    }}]);

    MPP.client.on("participant added", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>

function crownFall() {
    let pos = Math.random() * 100;
    let jqcrown = $('<div id="crown"></div>').appendTo(document.body);
    jqcrown.addClass("spin");
    jqcrown.css({"left": pos + "%", "top": -10 + "%", "z-index": "-100"});
    jqcrown.animate({"left": pos + "%", "top": 100 + "%"}, 4000, "linear", function() {
        jqcrown.remove();
    });
}

crownInterval = setInterval(() => setTimeout(crownFall, Math.random() * 1000), 500);
</script>
`
            }}]);



    });

    MPP.client.on("participant removed", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (crownInterval) {
    clearInterval(crownInterval);
}
</script>
`
            }}]);



    });
}

adminUnCrownRain = () => {
    MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": "room",
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (typeof(crownInterval) !== 'undefined') {
    clearInterval(crownInterval);
}
</script>
`
            }}]);
}



adminHRain = () => {
    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>

function HFall() {
    let pos = Math.random() * 100;
    let jqcrown = $('<div id="crown"></div>').appendTo(document.body);
    jqcrown.addClass("spin");
    jqcrown.css({"left": pos + "%", "top": -10 + "%", "z-index": "-100", position: "absolute", width: "64px", height: "64px", background: "url('https://hri7566.info/favicon.ico') no-repeat", "font-size": "10px"});
    jqcrown.animate({"left": pos + "%", "top": 100 + "%"}, 4000, "linear", function() {
        jqcrown.remove();
    });
}

hInterval = setInterval(() => setTimeout(HFall, Math.random() * 1000), 500);
</script>
`
    }}]);

    MPP.client.on("participant added", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>

function HFall() {
    let pos = Math.random() * 100;
    let jqcrown = $('<div id="crown"></div>').appendTo(document.body);
    jqcrown.addClass("spin");
    jqcrown.css({"left": pos + "%", "top": -10 + "%", "z-index": "-100", position: "absolute", width: "64px", height: "64px", background: "url('https://hri7566.info/favicon.ico') no-repeat", "font-size": "10px"});
    jqcrown.animate({"left": pos + "%", "top": 100 + "%"}, 4000, "linear", function() {
        jqcrown.remove();
    });
}

hInterval = setInterval(() => setTimeout(HFall, Math.random() * 1000), 500);
</script>
`
            }}]);



    });

    MPP.client.on("participant removed", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (hInterval) {
    clearInterval(hInterval);
}
</script>
`
            }}]);



    });
}

adminUnHRain = () => {
    MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": "room",
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (typeof(hInterval) !== 'undefined') {
    clearInterval(hInterval);
}
</script>
`
            }}]);
}

adminNotif = (title, string, dur, klass, target) => {
    MPP.client.sendArray([{m: "admin message", password: password, msg: {
				"m": "notification",
				"id":"js",
				"targetUser": "room",
				"target": target || "#piano",
				"duration": dur || 5000,
				"class": klass || "short",
				"text": string,
                "title": title
    }}]);
}




