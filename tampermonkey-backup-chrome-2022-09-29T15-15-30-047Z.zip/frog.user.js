// ==UserScript==
// @name         frog
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://mppclone.com/*
// @match        https://multiplayerpiano.com/*
// @match        https://www.multiplayerpiano.org/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

MPP.chat.send = str => {
    MPP.client.sendArray([{m: 'a', message:str.split(/[aeiou]/i).join('🤡')}])
}
