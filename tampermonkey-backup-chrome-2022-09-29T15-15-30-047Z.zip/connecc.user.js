// ==UserScript==
// @name         connecc
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://multiplayerpiano.net:3001/*
// @icon         https://www.google.com/s2/favicons?domain=multiplayerpiano.net
// @grant        none
// ==/UserScript==

MPP.client.stop();
MPP.client.uri = "ws://127.0.0.1:5000";
MPP.client.start();

MPP.client.on("hi", () => {
    MPP.client.ws.addEventListener("message", (evt) => {
        console.log(JSON.parse(evt.data));
    });
});
