// ==UserScript==
// @name         spam shit
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       hri7566
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

class RegistryObject {
    constructor (id) {
        this.id = id;
        Registry.register(this.id, this);
    }
}

class Registry {
    static map = new Map();

    static register(id, robj) {
        if (robj instanceof RegistryObject) {
            this.map.set(id, robj)l
        }
    }

    static deregister(id) {
        this.map.remove(id);
    }

    static loop(pref, cb) {
        this.map.forEach((val, id) => {
            if (!id.startsWith(pref)) return;
            cb(val, id);
        });
    }
}

class Prefix extends RegistryObject {
    static registryPrefix = `prefix`;

    static forEach(cb) {
        Registry.loop(this.registryPrefix, cb);
    }

    constructor (id, acc) {
        super(`prefix.${id}`);
    }
}

class Command extends RegistryObject {
    static registryPrefix = `command`;

    static forEach(cb) {
        Registry.loop(this.registryPrefix, cb);
    }

    constructor (id, acc, usage, desc, minargs, func, minrank, hidden) {
        super(`${Command.registryPrefix}.${id}`);

        this.accessors = acc;
        this.usage = usage;
        this.description = desc;
        this.minimumArguments = minargs;
        this.func = func;
        this.minimumRank = minrank;
        this.hidden = hidden || true;
    }

    static handleCommand(msg) {
        msg.args = msg.a.split(' ');

        Prefix.forEach(p => {
            if (msg.a.startsWith(p.accessor)) {
                msg.prefix = p;
            }
        });

        msg.cmd == msg.args[0].split(msg.usedPrefix).join(' ');
    }
}

class Bot {
    static participantMessagesEnabled = false;

    static start(cl) {
        this.bind();

        this.client = cl;
    }

    static sendChat(str) {
        this.client.sendArray([{
            m: "a",
            message: `\u034f${str}`
        }]);
    }

    static bind() {
        this.client.on("participant added", p => {
            if (this.participantMessagesEnable == true) {
                sendChat(`${p.name}, welcome to ${this.client.channel._id}! fucking making this as long as possible because you suck and your bots take five minutes to make`);
            }
        });

        this.client.on("participant remove", p => {
            if (this.participantMessagesEnable == true) {
                sendChat(`Goodbye, ${p.name}!`);
            }
        });

        this.client.on("a", msg => {
            Command.handleCommand(msg);
        });
    }
}

Bot.start(MPP.client);
