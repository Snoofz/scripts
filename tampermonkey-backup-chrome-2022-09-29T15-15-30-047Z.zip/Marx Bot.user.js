// Karl's Project
// ==UserScript==
// @name         Marx Bot
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Chat Bot
// @author       ✿🌿❤ ๖ۣۜḰᾄʀł☭Ṃᾄʀẋ ❤🌾✿
// @match        https://www.multiplayerpiano.com/*
// @match        https://piano.ourworldofpixels.com/*
// @match        https://mppclone.com/*
// @grant        none
// @require      file:///C:/Users/hri75/marxbot_custom.user.js
// ==/UserScript==
