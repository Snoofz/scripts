// ==UserScript==
// @name         name setter
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @match        https://mpp.terrium.net/*
// @grant        none
// ==/UserScript==

client = MPP.client;

client.on("hi", () => {
    setTimeout(() => {
        client.sendArray([{m:'userset', set:{name:"๖ۣۜH͜r̬i͡7566 👻"}}]);
        //client.sendArray([{m:'userset', set:{name:"⨣ ⨣⨀ ๖ۣۜH͜r̬i͡7566 ⨀⨣ ⨣"}}]);
    }, 2000);
});