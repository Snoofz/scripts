// ==UserScript==
// @name         fishing bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

client = MPP.client;
client2 = new Client("wss://www.multiplayerpiano.com:443");
client2.start();
client2.setChannel('test/fishing');

function chat(string) {
    client.sendArray([{m:'a', message:string}]);
}

function chat2(string) {
    client2.sendArray([{m:'a', message:string}]);
}

client.on('a', msg => {
    if (msg.p._id == client.getOwnParticipant()._id) {
        if (msg.a == ":fish") {
            chat("Autocatching fish...");
            chat2("/fish");

        }
        if (msg.a == ":changecolor") {
            chat("Attempting to change your color by eating a fish...");
            chat2("/eat");
        }
    }
});