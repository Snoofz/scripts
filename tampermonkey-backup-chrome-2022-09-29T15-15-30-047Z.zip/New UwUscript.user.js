// ==UserScript==
// @name         New UwUscript
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://mpp.hri7566.info/*
// @grant        none
// ==/UserScript==

let lib = "a b c d e f g h i j k l m n o p q r s t u v w x y z 1 2 3 4 5 6 7 8 9 0";
lib = lib.split(" ");

//UwU

/*
MPP.chat.send = (str) => {
    MPP.client.sendArray([{m:'a', message:str.split("l").join("w").split("r").join("w")}]);
}
*/

//fancy (from lingojam)

let rep = "𝓪 𝓫 𝓬 𝓭 𝓮 𝓯 𝓰 𝓱 𝓲 𝓳 𝓴 𝓵 𝓶 𝓷 𝓸 𝓹 𝓺 𝓻 𝓼 𝓽 𝓾 𝓿 𝔀 𝔁 𝔂 𝔃 1 2 3 4 5 6 7 8 9 0";
rep = rep.split(" ");
MPP.chat.send = (str) => {
    lib.forEach(char => {
        str = str.split(char).join(rep[lib.indexOf(char)]);
    });
    MPP.client.sendArray([{m:'a', message:str}]);
}
