// ==UserScript==
// @name         bot that is smart as dicks
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// @require      file://C:\Users\21hamptone\Downloads\bot.js
// ==/UserScript==
