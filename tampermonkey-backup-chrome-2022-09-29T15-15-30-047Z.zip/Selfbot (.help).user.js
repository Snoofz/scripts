// ==UserScript==
// @name         Selfbot (.help)
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://*.multiplayerpiano.com/*
// @match        https://mppclone.com/*
// @match        https://mpp.hri7566.info/*
// @grant        GM_getResourceText
// @grant        GM_addStyle
// @resource     MATERIAL_CSS https://unpkg.com/material-components-web@latest/dist/material-components-web.min.css
// @resource     ICONS_CSS https://fonts.googleapis.com/icon?family=Material+Icons
// @require      https://unpkg.com/material-components-web@latest/dist/material-components-web.min.js
// ==/UserScript==

/*
const material = GM_getResourceText("MATERIAL_CSS");
GM_addStyle(material);

const icons = GM_getResourceText("ICONS_CSS");
GM_addStyle(icons);

$("#bottom .relative").append(`<button class="mdc-button hri-test-button">
  <div class="mdc-button__ripple"></div>
  <span class="mdc-button__label">Button</span>
</button>`);

$("#hri-test-button").css("position", "absolute").css("left", "780px").css("top", "4px");

$("#hri-test-button .mdc-button__label").css("background-color", "white");
*/

// $("#chat").css("backdrop-filter", "blur(3px)").css("-webkit-backdrop-filter", "blur(3px)").css("transition-duration", "500ms");
// $("#room .more").css("background-color: #88998833");

String.prototype.toUnicode = function(){
    var result = "";
    let alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()[]{}\"`'\\/|;:,.<>?";
    for(var i = 0; i < this.length; i++){
        // Assumption: all characters are < 0xffff
        if (alphabet.indexOf(this[i]) == -1) {
            result += "\\u" + ("000" + this[i].charCodeAt(0).toString(16)).substr(-4);
        } else {
            result += this[i];
        }
    }
    return result;
};

let prefix = ".";
let cmds = [];
let name = "Selfbot";
let chat = (str) => {

    var li = $('<li><span class="name"/><span class="message"/>');

    // li.find(".name").text(MPP.client.getOwnParticipant().name + ":");
    li.find(".name").text("Selfbot:");
    li.find(".message").text(str);
    li.css("color", MPP.client.getOwnParticipant().color || "white");

    $("#chat ul").append(li);

    var eles = $("#chat ul li").get();
    for(var i = 1; i <= 50 && i <= eles.length; i++) {
        eles[eles.length - i].style.opacity = 1.0 - (i * 0.03);
    }
    if(eles.length > 50) {
        eles[0].style.display = "none";
    }
    if(eles.length > 256) {
        $(eles[0]).remove();
    }

    // scroll to bottom if not "chatting" or if not scrolled up
    if(!$("#chat").hasClass("chatting")) {
        MPP.chat.scrollToBottom();
    } else {
        var ele = $("#chat ul").get(0);
        if(ele.scrollTop > ele.scrollHeight - ele.offsetHeight - 50)
            MPP.chat.scrollToBottom();
    }
}

let uri = "wss://bot.hri7566.info:8080";
/*
window.ws = new WebSocket(uri);

ws.onopen = () => {
    chat("Selfbot: Connected to 7566");
};

ws.onclose = () => {
    chat('Selfbot: Disconnected from 7566');
};

ws.onerror = err => {
    console.error(err);
    chat('Selfbot: Error connecting to 7566 - Check log for details');
};

ws.onmessage = data => {
    chat(data);
};
*/

get7 = () => {
    /*
    ws.send(JSON.stringify({m:'get'}));
    let ret;
    ws.on('message', data => {
        let msg = JSON.parse(data);
        if (msg.m == "get") {
            ret = msg.p;
        }
    });

    return ret;
    */
}

send7 = str => {
    /*
    let j = JSON.stringify({m:'a', a:str, p: get7()});
    ws.send(j);
    */
}

let addCommand = (cmd, minargs, func) => {
    cmds.push({
        cmd: cmd,
        minargs: minargs,
        func: func
    });
}

function getPart(str) {
    let ret;
    Object.keys(MPP.client.ppl).forEach(id => {
        let p = MPP.client.ppl[id];
        if (p.name.toLowerCase().includes(str.toLowerCase()) || p._id.toLowerCase().includes(str.toLowerCase()) || p.id.toLowerCase().includes(str.toLowerCase())) {
            ret = p;
        }
    });

    return ret;
}

addCommand('help', 0, msg => {
    let ret = `${name} Commands:`;
    cmds.forEach(c => {
        ret += ` ${prefix}${c.cmd} | `;
    });
    ret = ret.trim().substring(0, ret.length - 2);
    chat(ret);
});

addCommand('js', 1, msg => {
    let ret;
    try {
        ret = "Console: " + eval(msg.argcat);
    } catch (err) {
        ret = err;
    }
    chat(ret);
});

addCommand('h', 1, msg => {
    send7(msg.a);
});

addCommand('id', 0, msg => {
    chat(msg.p._id);
});

addCommand('b', 1, msg => {
    if (typeof(getPart("b40df99cc2ca6f503fba77cb")) !== 'undefined') {
        MPP.client.sendArray([{m:'a', message:"//kickban 30 " + msg.argcat}]);
    } else {
        MPP.client.sendArray([{m:'kickban', _id: msg.argcat, ms: 30 * 60 * 1000}]);
    }
});

addCommand('w', 1, msg => {
    let part = getPart(msg.argcat);
    let str = "Could not find player."

    if (typeof(part) !== 'undefined') {
        str = `[${part._id.substr(0, 6)}] ${part.name}: `;
        Object.keys(part).forEach(key => {
            str += `${key == "name" ? key.toUnicode() : key}: ${part[key]} | `;
        });
        str = str.substring(0, str.length - 2);
        str = str.trim();
    }

    chat(str);
});

addCommand('color', 1, msg => {
    MPP.client.sendArray([{m:'userset', set:{color:`${msg.args[1]}`}}]);
})

MPP.chat.send = (str) => {
    let msg = {
        p: MPP.client.getOwnParticipant(),
        a: str,
        args: str.split(' ')
    }

    msg.cmd = msg.args[0].split(prefix).join('');
    msg.argcat = msg.a.substring(prefix.length + msg.cmd.length).trim()

    if (str.startsWith(prefix)) {
        chat(str);
        cmds.forEach(c => {
            if (msg.cmd == c.cmd) {
                if (msg.args.length >= c.minargs) {
                    c.func(msg);
                }
            }
        });
    } else {
        MPP.client.sendArray([{m:'a', message:str}])
    }
}

MPP.client.on("participant added", p => {
    chat(`[${p._id}] ${p.name} joined.`);
});

MPP.client.on("participant removed", p => {
    chat(`[${p._id}] ${p.name} left.`);
});

// ==UserScript==
// @name         Hri7566's Bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Hri7566's tampermonkey bot
// @author       Hri7566
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

if (navigator.userAgent.includes("Electron")) {
    window.electron = true;
}

window.client = MPP.client;

window.sendChat = str => {
    client.sendArray([{
        m: "a",
        message: `\u034f${str}`
    }]);
}

window.setChannelSettings = set => {
    client.sendArray([{
        m: "chset",
        set: set
    }]);
}

window.msgBox = (title, text, html) => {
    new MPP.Notification({
        id: "hri-bot-msg",
        title: title,
        text: text,
        target: "#piano",
        duration: 7000,
        html: html
    });
}

var gModal;

var modalHandleEsc = (evt) => {
    if(evt.keyCode == 27) {
        closeModal();
        evt.preventDefault();
        evt.stopPropagation();
    }
}

var openModal = (selector, focus) => {
    MPP.chat.blur();
    $(document).on("keydown", modalHandleEsc);
    $("#modal #modals > *").hide();
    $("#modal").fadeIn(250);
    $(selector).show();
    setTimeout(function() {
        $(selector).find(focus).focus();
    }, 100);
    gModal = selector;
}

var closeModal = () => {
    $(document).off("keydown", modalHandleEsc);
    $("#modal").fadeOut(100);
    $("#modal #modals > *").hide();
    gModal = null;
}

window.Bot = class {
    static usedBot = JSON.parse(localStorage.getItem('hriUsed')) == true;
    static started = false;
    static enabled = true;

    static themeColor = new Color("#4488aa");
    static blurDisabled = false;
    static voiceKeyword = "computer";

    static cleverbotWS = new WebSocket('wss://mpp.hri7566.info:25563');

    static commands = [];
    static Command = class {
        constructor (cmd, usage, minargs, func, minrank, hidden) {
            this.cmd = cmd;
            this.usage = usage;
            this.minargs = minargs;
            this.func = func;
            this.minrank = minrank;
            this.hidden = hidden;
        }
    }

    static User = class {
        constructor (name, _id, color, rank) {
            this.name = name;
            this._id = _id;
            this.color = color;
            this.rank = typeof(rank) !== 'undefined' ? rank : {name: "None", _id: 0};
        }
    }

    static cursor = {
        enabled: false,
        pos: {
            x: 50,
            y: 50
        },
        vel: {
            x: 1,
            y: 10
        },
        acc: {
            x: 0,
            y: 0
        }
    }

    static start(client) {
        if (!client.isConnected()) return;

        this.userdata = (() => {
            if (localStorage.getItem('hri-userdata') == null || localStorage.getItem('hri-userdata') == 'null' || typeof(JSON.parse(localStorage.getItem('hri-userdata'))) == 'string') {
                let obj = {};
                obj[client.getOwnParticipant()._id] = {
                    name: client.getOwnParticipant().name,
                    color: client.getOwnParticipant().color,
                    _id: client.getOwnParticipant()._id,
                    rank: {
                        name: "Owner",
                        _id: 4
                    }
                }
                localStorage.setItem('hri-userdata', JSON.stringify(obj));
                return obj;
            } else {
                return JSON.parse(localStorage.getItem('hri-userdata'));
            }
        })();

        this.started = true;

        closeModal();

        if (!this.usedBot) {
            msgBox("Welcome", undefined, 'This bot was made by <a href="https://gitlab.com/Hri7566" target="_blank">Hri7566</a>.');
            localStorage.setItem('hriUsed', true);
        }

        this.addHTML();
        this.handleSpeechRecognition();
        this.startCursor();
        this.commands = [];
        this.prefix = '?';

        this.cleverbotWS.addEventListener('message', evt => {
            sendChat(`AI: ${evt.data}`);
        });

        client.on('a', msg => {
            msg.args = msg.a.split(' ');
            msg.cmd = msg.args[0].toLowerCase().substring(this.prefix.length).trim();
            msg.argcat = msg.a.substring(this.prefix.length + msg.cmd.length).trim();
            msg.user = this.getUser(msg.p);
            msg.rank = this.getRank(msg.p);

            this.commands.forEach(cmd => {
                if (msg.cmd == cmd.cmd && msg.args[0].startsWith(this.prefix)) {
                    if (msg.rank._id < 0) {
                        sendChat("You are banned.");
                        return;
                    }

                    if (msg.args.length - 1 < cmd.minargs) {
                        sendChat(`Not enough arguments. Usage: ${this.getUsage(cmd.usage)}`);
                        return;
                    }

                    if (msg.rank._id < cmd.minrank) {
                        sendChat(`You do not have permission to use '${msg.cmd}'.`);
                        return;
                    }

                    let out = cmd.func(msg, this);
                    if (typeof(out) !== 'undefined') {
                        if (out !== null) {
                            sendChat(out);
                        }
                    }
                }
            });
        });

        this.addCommand("help", `&PREFIXhelp (command)`, 0, msg => {
            let out = "";
            if (!msg.args[1]) {
                out = "Commands: ";
                this.commands.forEach(cmd => {
                    if (msg.rank._id >= cmd.minrank && !cmd.hidden) {
                        out += ` ${this.prefix}${cmd.cmd} | `;
                    }
                });
                out = out.substring(0, out.length - 2);
            } else {
                out = "Usage: ";
                this.commands.forEach(cmd => {
                    if (msg.argcat == cmd) {
                        out += this.getUsage(cmd.usage);
                    }
                });
            }
            return out;
        }, 0, false);

        /*
        this.addCommand("ai", `&PREFIXai (text)`, 0, msg => {
            this.cleverbotWS.send(msg.argcat);
        }, 0, false);
        */

        this.addCommand("about", `&PREFIXabout`, 0, msg => {
            return "This bot is Hri7566's userscript.";
        }, 0, false);

        this.addCommand("8ball", `&PREFIX8ball (question)`, 1, msg => {
            let ballanswers = [
                "As I see it, yes",
                "Ask again later",
                "Better not tell you now",
                "Cannot predict now",
                "Concentrate and ask again",
                "Don't count on it",
                "It is certain",
                "It is decidedly so",
                "Most likely",
                "My reply is no",
                "My sources say no",
                "Outlook not so good",
                "Outlook good",
                "Reply hazy, try again",
                "Signs point to yes",
                "Very doubtful",
                "Without a doubt",
                "Yes",
                "Yes - definitely",
                "You may rely on it"
            ]
            return ballanswers[Math.floor(Math.random() * ballanswers.length)];
        }, 0, false);

        this.addCommand("rank", `&PREFIXrank [user]`, 0, msg => {
            let rank = msg.rank;
            if (msg.args[1]) {
                let user = this.getUser(msg.argcat);
                if (!user) return `Could not find user.`;
                rank = this.getRank(user);
            }
            return `Rank: ${rank.name} [${rank._id}]`;
        }, 0, false);

        this.addCommand("s", `&PREFIXs (cmd)`, 1, msg => {
            this.handleSpecialCmd(msg.argcat);
        }, 4, true);

        this.addCommand("js", `&PREFIXjs (eval)`, 1, (msg, bot) => {
            let ret;
            try {
                let ev = eval(msg.argcat);
                ret = `✔️ (${typeof ev}) ${eval(msg.argcat)}`;
            } catch (err) {
                ret = `❌ ${err}`;
            }
            return ret;
        }, 4, false);

        this.addCommand("setrank", `&PREFIXsetrank (user) (rank id)`, 2, (msg, bot) => {
            let lastarg = msg.args[msg.args.length - 1].trim();
            if (isNaN(lastarg)) return `Rank ID must be a number.`;
            if (parseInt(lastarg) >= msg.rank._id) return `You can't set a rank that high.`;

            let finder = getPart(msg.argcat.substring(0, lastarg.length));
            let user = this.getUser(finder);
            if (!user) return `Could not find user.`;

            let outrank = this.getRankByID(parseInt(lastarg));
            this.setRank(user, outrank);
            this.saveUserData();
            return `User ${user.name}'s rank was set to ${outrank.name} [${outrank._id}].`;
        }, 0, false);
    }

    static addCommand(cmd, usage, minargs, func, minrank, hidden) {
        this.commands.push(new this.Command(cmd, usage, minargs, func, minrank, hidden));
    }

    static getUser(p) {
        let ids = Object.keys(this.userdata);
        let foundUser;

        ids.forEach(id => {
            let u = this.userdata[id];
            if (p._id == u._id) {
                foundUser = u;
            }
        });

        if (typeof(foundUser) == 'undefined') {
            foundUser = new this.User(p.name, p._id, p.color);
            this.userdata[p._id] = foundUser;
        }

        this.saveUserData();

        return foundUser;
    }

    static getRank(p) {
        let user = this.getUser(p);
        return user.rank;
    }

    static setRank(p, rank) {
        this.userdata[p._id].rank = rank;
    }

    static getRankByID(id) {
        switch (id) {
            case 0:
                return {name: "None", _id: 0};
                break;
            case 1:
                return {name: "Moderator", _id: 1};
                break;
            case 2:
                return {name: "Admin", _id: 2};
                break;
            case 3:
                return {name: "Godmin", _id: 3};
                break;
            case 4:
                return {name: "Owner", _id: 4};
                break;
        }
    }

    static getUsage(str) {
        return str.split('&PREFIX').join(this.prefix);
    }

    static saveUserData() {
        localStorage.setItem("hri-userdata", JSON.stringify(this.userdata));
    }

    static addHTML() {
        this.addButtons();
        this.addModal();
    }

    static addButtons() {
        $("#bottom .relative").append(`<div id="hri-bot-button" class="ugly-button translate">Bot Settings</div>`);
        $("#hri-bot-button").css("position", "absolute").css("left", "780px").css("top", "4px").on("click", () => {
            this.openSettings();
        });
    }

    static addModal() {
        $("#modal #modals").append(`
            <div id="hri-bot-settings" class="dialog">
                <p><label><input type="checkbox" name="enabled" class="checkbox" checked>Bot Enabled</label></p>
                <p><label>Theme color:  &nbsp;<input type="color" name="themecolor" placeholder="" maxlength="7" class="color"></label></p>
                <button class="submit">APPLY</button>
            </div>
        `);
        $("#hri-bot-settings").css("height", "400px").css("margin-top", "-200px");

        $("#hri-bot-settings .submit").click(evt => {
            var name = $("#new-room .text[name=name]").val();
            this.enabled = $("#hri-bot-settings input[name=enabled]").is(":checked");
            this.themeColor = new Color($("#hri-bot-settings input[name=themecolor]").val());
            this.blurDisabled = $("#hri-bot-settings input[name=disableblur]").is(":checked");
            this.updateTheme();
			closeModal();
        });
    }

    static openSettings() {
        openModal("#hri-bot-settings");
        setTimeout(() => {
            $("#hri-bot-settings input[name=enabled]").prop("checked", this.enabled);
            $("#hri-bot-settings input[name=themecolor]").val(this.themeColor.toHexa());
            $("#hri-bot-settings input[name=disableblur]").prop("checked", this.blurDisabled);
        }, 250);
    }

    static updateTheme() {
        let hex = this.themeColor.toHexa();
        let darkened = new Color(this.themeColor.toHexa());
        darkened.r -= 20;
        if (darkened.r < 0) darkened.r = 0;
        darkened.g -= 20;
        if (darkened.g < 0) darkened.g = 0;
        darkened.b -= 20;
        if (darkened.b < 0) darkened.b = 0;

        $("#modal .bg").css("background", hex + '44');
        $("#modal #modals .dialog").css("background", hex + '88').css("border", "2px solid " + darkened.toHexa() + '88');
        $(".ugly-button").css("background", hex + '44').css("border", "2px solid " + darkened.toHexa() + '44');

        if (this.blurDisabled == false) {
            $("#modal .bg").css("backdrop-filter", "blur(2px)");
            $("#modal #modals .dialog").css("backdrop-filter", "blur(5px)");
            $(".ugly-button").css("backdrop-filter", "blur(5px)");
        }
    }

    static handleSpeechRecognition() { // speech synthesis from the keeper of A T L A S (written by Yoshify)
        function capitalizeFirstLetter(string) {
            return string[0].toUpperCase() + string.substr(1).trim() + ".";
        }

        window.Voice = new webkitSpeechRecognition();

        Voice.lang = 'en';

        var chatEnabled = false;

        var listening = true;
        Voice.continuous = true;
        Voice.interimResults = true;

        Voice.start();

        Voice.onend = () => {
            Voice.start();
        }

        Voice.onresult = (event) => {
            if (event.results.length > 0) {
                var result = event.results[event.results.length - 1];
                if (result.isFinal) {
                    let str = capitalizeFirstLetter(result[result.length - 1].transcript).toLowerCase();
                    if (!str.startsWith(this.voiceKeyword)) {
                        if (chatEnabled) {
                            MPP.chat.send(str);
                        }
                    } else {
                        this.handleSpecialCmd(str);
                    }
                }
            }
        }

        function handleKeyDown(evt) {
            var code = parseInt(evt.keyCode);
            if (code == 220) { //Yoshify's speech to text
                if (listening) {
                    listening = false;
                    Voice.onend = () => {};
                    Voice.stop();
                    msgBox('Speech to Text', 'Stopping Capture');
                } else {
                    listening = true;
                    Voice.start();
                    Voice.onend = () => {
                        Voice.start();
                    }
                    msgBox('Speech to Text', 'Listening');
                }
            }
        }

        $(document).on("keydown", handleKeyDown);
    }

    static handleSpecialCmd(str) {
        let args = str.split(' ');
        let cmd = args[1];
        let argcat = str.substring(args[0].length + cmd.length + 1).trim();
        if (args.length < 2) return;
        if (cmd == 'fish') {
            MPP.chat.send("/fish");
        }
        if (cmd == 'real' || cmd == 'reel') {
            MPP.chat.send("/reel");
        }
        if (cmd == 'eat') {
            MPP.chat.send("/eat");
        }
        if (cmd == "change" || cmd == "set") {
            if (argcat.includes("keyword")) {
                this.voiceKeyword = args[args.length - 1];
                msgBox("Voice Keyword Changed", "Voice keyword has changed to " + this.voiceKeyword + ".");
            }
        }
        if (cmd == "reset") {
            if (argcat.includes("color")) {
                if (MPP.client.getOwnParticipant().color !== "#9900ff") {
                    MPP.client.sendArray([{m:'userset', set:{color:"#9900ff"}}]);
                }
            } else if (argcat.includes("name")) {
                if (MPP.client.getOwnParticipant().name !== "๖ۣۜH͜r̬i͡7566") {
                    MPP.client.sendArray([{m:'userset', set:{name: "๖ۣۜH͜r̬i͡7566"}}]);
                }
            }
        }
        if (cmd == "cursor") {
            if (argcat.includes("on")) {
                this.cursor.enabled = true;
                console.log("cursor on");
            } else if (argcat.includes("off")) {
                this.cursor.enabled = false;
                console.log("cursor off");
            }
        }
        if (cmd == "chat") {
            if (argcat.includes("on")) {
                chatEnabled = true;
            } else if (argcat.includes("off")) {
                chatEnabled = false;
            }
        }
        if (cmd == "ai") {
            if (argcat) {
                this.cleverbotWS.send(argcat);
            }
        }
        if (cmd == "mute") {
            MPP.piano.audio.setVolume(0);
        }
        if (cmd == "unmute") {
            MPP.piano.audio.setVolume(0.16);
        }
    }

    static startCursor() {
        this.cursor.vel.x = 1;
        this.cursor.vel.y = 10;

        this.cursorInterval = setInterval(() => {
            if (this.cursor.enabled == true) {
                client.sendArray([{m: "m", x: this.cursor.pos.x, y: this.cursor.pos.y}]);
            }
        }, 1000/20);

        this.cursorUpdate = setInterval(() => {
            this.cursor.pos.x += this.cursor.vel.x;
            if (this.cursor.pos.x > 100 || this.cursor.pos.x < 0) {
                if (this.cursor.pos.y > 100 - (this.cursor.vel.y * 2) || this.cursor.pos.y < 0 - (this.cursor.vel.y * 2)) {
                    this.cursor.vel.y = -this.cursor.vel.y;
                }
                this.cursor.pos.y += this.cursor.vel.y;
                this.cursor.vel.x = -this.cursor.vel.x;
            }
        }, 1000/60);
    }
}

setTimeout(() => {Bot.start(client)}, 1000);









