// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @grant        none
// ==/UserScript==

let cl = MPP.client;

let gChatMutes = (localStorage.chatMutes ? localstorage.chatMutes : '').split(',').filter(v => v);

// 10211145
// For todays date;
Date.prototype.today = function () {
    return ((this.getDate() < 10)?"0":"") + this.getDate() +"/"+(((this.getMonth()+1) < 10)?"0":"") + (this.getMonth()+1) +"/"+ this.getFullYear();
}

// For the time now
Date.prototype.timeNow = function () {
     return ((this.getHours() < 10)?"0":"") + this.getHours() +":"+ ((this.getMinutes() < 10)?"0":"") + this.getMinutes() +":"+ ((this.getSeconds() < 10)?"0":"") + this.getSeconds();
}

chat.receive = msg => {
    if (!msg.hasOwnProperty("m")) return;
    if (gChatMutes.indexOf(msg.m == "dm" ? msg.sender._id : msg.p._id) !== -1) return;

    let liString = '<li>';
    let isSpecialDm = false;

    if (gShowTimestampsInChat) liString += `<span> </span>`;

}
