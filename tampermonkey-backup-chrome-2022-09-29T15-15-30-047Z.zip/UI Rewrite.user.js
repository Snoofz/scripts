// ==UserScript==
// @name         UI Rewrite
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

window.cl = MPP.client;

let muteButton = `<div id="mute-btn" class="ugly-button">Mute Piano</div>`;

$("#bottom .relative").append(muteButton);

$("#mute-btn").css({
    position: 'absolute',
    right: '150px',
    top: '4px'
});

$("#mute-btn").on("click", toggleMute);

function toggleMute() {
    if (this.enabled) {
        $("#piano").fadeTo(1000, 1);
        $("#volume").fadeTo(1000, 1);
        $("#volume #volume-slider").prop("disabled", false);
        $("#mute-btn").html("Mute Piano");
        MPP.piano.audio.masterGain.gain.value = parseFloat($("#volume #volume-slider").val());
        this.enabled = false;
    } else {
        $("#piano").fadeTo(1000, 0.2);
        $("#volume").fadeTo(1000, 0.2);
        $("#volume #volume-slider").prop("disabled", true);
        $("#mute-btn").html("Unmute Piano");
        MPP.piano.audio.masterGain.gain.value = 0;
        this.enabled = true;
    }
}

toggleMute.prototype.enabled = true;
