// ==UserScript==
// @name         DVD
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        http*://www.multiplayerpiano.com/*
// @match        https://mppclone.com/*
// @grant        none
// ==/UserScript==

client = MPP.client;

function chat(string) {
    // client.sendArray([{m:'a', message:string}]);
}

var toggle = true;
var x = 0;
var y = 0;
var vx = 2/5;
var vy = 2/7;
var stats = {
    edgehits:0,
    cornerhits:0
};

cursor = setInterval(function() {
    if ((x > 100) || (x < 0)) {
        vx = -vx;
        stats.edgehits += 1;
    }
    if ((y > 100) || (y < 0)) {
        vy = -vy;
        stats.edgehits += 1;
    }
    if ((x < 0) && (y < 0)) {
        stats.cornerhits += 1;
    }
    if ((x > 100) && (y < 0)) {
        stats.cornerhits += 1;
    }
    if ((x < 0) && (y > 100)) {
        stats.cornerhits += 1;
    }
    if ((x > 100) && (y > 100)) {
        stats.cornerhits += 1;
    }
    x = x + vx;
    y = y + vy;
}, 25);

cursorsend = setInterval(function() {
    if (toggle == true) {
        client.sendArray([{m:'m', x:x, y:y}]);
    }
}, 25);

client.on("a", msg => {
    let args = msg.a.split(' ');
    let cmd = args[0].toLowerCase();
    let argcat = msg.a.substring(cmd.length).trim();
    switch (cmd) {
        case "dvd!toggle":
            if (toggle == true) {
                toggle = false;
                chat("The cursor is now hidden.");
            } else if (toggle == false) {
                toggle = true;
                chat("The cursor is no longer hidden");
            }
            break;
        case "dvd!stats":
            chat(`Edge hits: ${stats.edgehits} | Corner hits: ${stats.cornerhits}`);
            break;
        case "dvd!help":
            chat("Commands: dvd!help | dvd!about | dvd!toggle | dvd!stats");
            break;
        case "dvd!about":
            chat("This bot was made by Hri7566.");
            break;
    }
});