// ==UserScript==
// @name         hmpp admin
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mpp.hri7566.info/*
// @match        https://mppkinda.com/*
// @grant        none
// ==/UserScript==

let password = localStorage.password || "burgerass";

adminChat = (string) => {
    MPP.client.sendArray([{
        m:'admin message',
        password:password,
        msg: {
            m:'eval',
            str: `this.rooms.get("${MPP.client.channel._id}").chat({participantId:"0"}, {p:{name:"mpp", color:"#ffffff",_id:"0",id:"0"}, message:"${string}"})`
        }
    }])
}

adminJS = (string) => {
if (typeof(string) !== 'string') string = string.toString();
MPP.client.sendArray([{m: "admin message", password: password, msg: {
				"m": "notification",
				"id":"js",
				"targetUser": "room",
				"target": "#names",
				"duration": 1,
				"class":"short",
				"html": `<script>${string.substring(string.indexOf("{")).substr(1, string.substring(string.indexOf("{")).length - 2)}</script>`
}}]);
}

adminHTML = (string, dur, klass) => {
    MPP.client.sendArray([{m: "admin message", password: password, msg: {
				"m": "notification",
				"id":"js",
				"targetUser": "room",
				"target": "#piano",
				"duration": dur || 5000,
				"class": klass || "short",
				"html": string,
    }}]);
}

adminNotif = (title, string, dur, klass, target) => {
    MPP.client.sendArray([{m: "admin message", password: password, msg: {
				"m": "notification",
				"id":"js",
				"targetUser": "room",
				"target": target || "#piano",
				"duration": dur || 5000,
				"class": klass || "short",
				"text": string,
                "title": title
    }}]);
}

adminChownJS = () => {
let id = MPP.client.getOwnParticipant().id;
MPP.client.sendArray([{m: "admin message", password: password, msg: {
				"m": "notification",
				"id":"ebsprite",
				"targetUser": "room",
				"target": "#names",
				"duration": 1,
				"class":"short",
				"html": `<script>
MPP.client.sendArray([{m:'chown', id:'${id}'}]);
</script>`
			}}]);
}

adminChown = () => {
id = MPP.client.getOwnParticipant().id;
MPP.client.sendArray([{m: "admin message", password: password, msg: {
				m:"chown",
    id:id
			}}]);
}

adminColor = (str, id) => {
MPP.client.sendArray([{m: "admin message", password: password, msg: {
				"m": "color",
				"_id":id || MPP.client.getOwnParticipant()._id,
				"color": str
			}}]);
}

getUser = i => {
    let out;
    for (let id in MPP.client.ppl) {
        let p = MPP.client.ppl[id];

        if (p._id.toLowerCase().includes(i.toLowerCase())) {
            out = p;
        }
    }
    return out;
}

adminRainbow = (id) => {

let p = getUser(id);

MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "7000",
        "class":"short",
        "html": `
<script>
if (!MPP.client.ppl["${p.id}"].nameDiv.classList.contains("rainbow-bg")) {
    MPP.client.ppl["${p.id}"].nameDiv.classList.add("rainbow-bg");
}
if (!MPP.client.ppl["${p.id}"].cursorDiv.classList.contains("rainbow")) {
    MPP.client.ppl["${p.id}"].cursorDiv.classList.add("rainbow");
}
</script>
`
    }}]);

MPP.client.on("participant added", pd => {


    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": pd._id,
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
if (!MPP.client.ppl["${p.id}"].nameDiv.classList.contains("rainbow-bg")) {
    MPP.client.ppl["${p.id}"].nameDiv.classList.add("rainbow-bg");
}
if (!MPP.client.ppl["${p.id}"].cursorDiv.classList.contains("rainbow")) {
    MPP.client.ppl["${p.id}"].cursorDiv.classList.add("rainbow");
}
</script>
`
    }}]);



});

}


adminSpin = () => {
    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
if (!MPP.piano.rootElement.classList.contains("spin")) {
    MPP.piano.rootElement.classList.add("spin");
}
</script>
`
    }}]);

MPP.client.on("participant added", p => {


    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": p._id,
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
if (!MPP.piano.rootElement.classList.contains("spin")) {
    MPP.piano.rootElement.classList.add("spin");
}
</script>
`
    }}]);



});
}


adminUnspin = () => {
    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
if (MPP.piano.rootElement.classList.contains("spin")) {
    MPP.piano.rootElement.classList.remove("spin");
}
</script>
`
    }}]);

MPP.client.on("participant added", p => {


    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": p._id,
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
if (MPP.piano.rootElement.classList.contains("spin")) {
    MPP.piano.rootElement.classList.remove("spin");
}
</script>
`
    }}]);



});
}

adminCrownRain = () => {
    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>

function crownFall() {
    let pos = Math.random() * 100;
    let jqcrown = $('<div id="crown"></div>').appendTo(document.body);
    jqcrown.addClass("spin");
    jqcrown.css({"left": pos + "%", "top": -10 + "%", "z-index": "-100"});
    jqcrown.animate({"left": pos + "%", "top": 100 + "%"}, 4000, "linear", function() {
        jqcrown.remove();
    });
}

crownInterval = setInterval(() => setTimeout(crownFall, Math.random() * 1000), 50);
</script>
`
    }}]);

    MPP.client.on("participant added", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>

function crownFall() {
    let pos = Math.random() * 100;
    let jqcrown = $('<div id="crown"></div>').appendTo(document.body);
    jqcrown.addClass("spin");
    jqcrown.css({"left": pos + "%", "top": -10 + "%", "z-index": "-100"});
    jqcrown.animate({"left": pos + "%", "top": 100 + "%"}, 4000, "linear", function() {
        jqcrown.remove();
    });
}

crownInterval = setInterval(() => setTimeout(crownFall, Math.random() * 1000), 500);
</script>
`
            }}]);



    });

    MPP.client.on("participant removed", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (crownInterval) {
    clearInterval(crownInterval);
}
</script>
`
            }}]);



    });
}

adminUnCrownRain = () => {
    MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": "room",
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (typeof(crownInterval) !== 'undefined') {
    clearInterval(crownInterval);
}
</script>
`
            }}]);
}



adminHRain = () => {
    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>

function HFall() {
    let pos = Math.random() * 100;
    let jqcrown = $('<div id="crown"></div>').appendTo(document.body);
    jqcrown.addClass("spin");
    jqcrown.css({"left": pos + "%", "top": -10 + "%", "z-index": "-100", position: "absolute", width: "64px", height: "64px", background: "url('https://hri7566.info/favicon.ico') no-repeat", "font-size": "10px"});
    jqcrown.animate({"left": pos + "%", "top": 100 + "%"}, 4000, "linear", function() {
        jqcrown.remove();
    });
}

hInterval = setInterval(() => setTimeout(HFall, Math.random() * 1000), 500);
</script>
`
    }}]);

    MPP.client.on("participant added", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>

function HFall() {
    let pos = Math.random() * 100;
    let jqcrown = $('<div id="crown"></div>').appendTo(document.body);
    jqcrown.addClass("spin");
    jqcrown.css({"left": pos + "%", "top": -10 + "%", "z-index": "-100", position: "absolute", width: "64px", height: "64px", background: "url('https://hri7566.info/favicon.ico') no-repeat", "font-size": "10px"});
    jqcrown.animate({"left": pos + "%", "top": 100 + "%"}, 4000, "linear", function() {
        jqcrown.remove();
    });
}

hInterval = setInterval(() => setTimeout(HFall, Math.random() * 1000), 500);
</script>
`
            }}]);



    });

    MPP.client.on("participant removed", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (hInterval) {
    clearInterval(hInterval);
}
</script>
`
            }}]);



    });
}

adminUnHRain = () => {
    MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": "room",
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (typeof(hInterval) !== 'undefined') {
    clearInterval(hInterval);
}
</script>
`
            }}]);
}

adminSubscribe = () => {
    MPP.client.sendArray([{
        m: "subscribe to admin stream",
        password: password,
        interval_ms: 10000
    }]);
}

adminUnsubscribe = () => {
    MPP.client.sendArray([{
        m: "subscribe to admin stream",
        password: password,
        interval_ms: 10000
    }]);
}

MPP.client.on("data", msg => {
    // console.log(msg);
});

















adminDickRain = () => {
    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>

function crownFall() {
    let pos = Math.random() * 100;
    let jqcrown = $('<div id="crown"></div>').appendTo(document.body);
    jqcrown.addClass("spin");
    jqcrown.css({"left": pos + "%", "top": -10 + "%", "z-index": "-100", position: "absolute", width: "64px", height: "64px", background: "url('https://www.pngitem.com/pimgs/m/418-4182603_dickbutt-stiker-freetoedit-dickbutt-png-transparent-png.png') no-repeat", "font-size": "10px"});
    jqcrown.animate({"left": pos + "%", "top": 100 + "%"}, 4000, "linear", function() {
        jqcrown.remove();
    });
}

crownInterval = setInterval(() => setTimeout(crownFall, Math.random() * 1000), 50);
</script>
`
    }}]);

    MPP.client.on("participant added", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>

function crownFall() {
    let pos = Math.random() * 100;
    let jqcrown = $('<div id="crown"></div>').appendTo(document.body);
    jqcrown.addClass("spin");
    jqcrown.css({"left": pos + "%", "top": -10 + "%", "z-index": "-100", position: "absolute", width: "860px", height: "697px", background: "url('https://www.pngitem.com/pimgs/m/418-4182603_dickbutt-stiker-freetoedit-dickbutt-png-transparent-png.png') no-repeat", "font-size": "10px"});
    jqcrown.animate({"left": pos + "%", "top": 100 + "%"}, 4000, "linear", function() {
        jqcrown.remove();
    });
}

crownInterval = setInterval(() => setTimeout(crownFall, Math.random() * 1000), 500);
</script>
`
            }}]);



    });

    MPP.client.on("participant removed", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (crownInterval) {
    clearInterval(crownInterval);
}
</script>
`
            }}]);



    });
}

adminUnDickRain = () => {
    MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": "room",
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (typeof(crownInterval) !== 'undefined') {
    clearInterval(crownInterval);
}
</script>
`
            }}]);
}











adminStarfield = () => {
    MPP.client.sendArray([{
    m: "admin message",
    password: password,
    msg: {
        "m": "notification",
        "id":"ebsprite",
        "targetUser": "room",
        "target": "#names",
        "duration": "1",
        "class":"short",
        "html": `
<script>
function genStarSize() {
    if (Math.random() < 0.01) {
        return 10;
    } else {
        return 3;
    }
}

function spawnStar() {
    let pos = {
        x: Math.random() * 100,
        y: Math.random() * 100
    }

    let jqstar = $('<div id="star"></div>').appendTo(document.body);
    let starSize = genStarSize();

    jqstar.css({
        "left": pos.x + "%",
        "top": pos.y + "%",
        "z-index": "-100",
        "background-color": "#bbb",
        "display": "inline-block",
        "border-radius": "50%",
        "position": "absolute",
        "width": starSize + "px",
        "height": starSize + "px",
        "display": "none"
    });

    $(jqstar).fadeIn(1000, () => {
        $(jqstar).fadeOut(30000, () => {
            $(jqstar).remove();
        });
    });
}

window.starInterval = setInterval(() => {
    setTimeout(spawnStar, Math.random() * 1000)
}, 250);
</script>
`
    }}]);

    MPP.client.on("participant added", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
function genStarSize() {
    if (Math.random() < 0.01) {
        return 10;
    } else {
        return 3;
    }
}

function spawnStar() {
    let pos = {
        x: Math.random() * 100,
        y: Math.random() * 100
    }

    let jqstar = $('<div id="star"></div>').appendTo(document.body);
    let starSize = genStarSize();

    jqstar.css({
        "left": pos.x + "%",
        "top": pos.y + "%",
        "z-index": "-100",
        "background-color": "#bbb",
        "display": "inline-block",
        "border-radius": "50%",
        "position": "absolute",
        "width": starSize + "px",
        "height": starSize + "px",
        "display": "none"
    });

    $(jqstar).fadeIn(1000, () => {
        $(jqstar).fadeOut(30000, () => {
            $(jqstar).remove();
        });
    });
}

window.starInterval = setInterval(() => {
    setTimeout(spawnStar, Math.random() * 1000)
}, 250);
</script>
`
            }}]);



    });

    MPP.client.on("participant removed", p => {
        MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": p._id,
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (typeof(starInterval) !== 'undefined') {
    clearInterval(starInterval);
}
</script>
`
            }}]);



    });
}

adminUnStarfield = () => {
    MPP.client.sendArray([{
            m: "admin message",
            password: password,
            msg: {
                "m": "notification",
                "id":"ebsprite",
                "targetUser": "room",
                "target": "#names",
                "duration": "1",
                "class":"short",
                "html": `
<script>
if (typeof(starInterval) !== 'undefined') {
    clearInterval(starInterval);
}
</script>
`
            }}]);
}
