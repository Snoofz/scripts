// ==UserScript==
// @name         Download Chat
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Chat download button for mppclone
// @author       Hri7566
// @match        https://mppclone.com/*
// @match        https://multiplayerpiano.com/*
// @match        https://www.multiplayerpiano.org/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mppclone.com
// @grant        none
// ==/UserScript==

let btn = `<div id="chat-download-btn" class="ugly-button">Download Chat</div>`

$("#bottom .relative").append(btn);

$("#chat-download-btn").css({
    position: "absolute",
    left: "1020px",
    top: "32px"
});

$("#chat-download-btn").on("click", () => {
    let list = [];

    $("#chat ul li").each((i, ele) => {
        let str = "";
        let ts = $(ele).find(".timestamp");
        str += $(ts).text() + " ";

        let shortID = $(ele).find(".id");
        str += $(shortID).text() + " ";

        let name = $(ele).find(".name");
        str += $(name).text() + " ";

        let mes = $(ele).find(".message");
        str += $(mes).text() + "\n";

        list.push(str);
    });

    let uri = URL.createObjectURL(new Blob(list, {type: "text/plain"}));

    new MPP.Notification({
        id: "chat-download",
        class: "classic",
        title: "Chat Download",
        html: `<a href="${uri}" download>Here</a> is your download.`,
        duration: 7000,
        target: "#piano"
    });
});
