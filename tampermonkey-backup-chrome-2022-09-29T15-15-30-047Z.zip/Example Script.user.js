// ==UserScript==
// @name         Example Script
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

var prefix = "8";
var commands = [];

function sendChat(str) {
    MPP.chat.send("\u034f"+str);
}

function getUsage(cmd) {
    let c = commands.find(el => {
        cmd == el.cmd
    });

    return c.usage.split("PREFIX").join(prefix);
}

window.addCommand = function (cmd, usage, minargs, func, minrank, hidden) {
    commands.push({
        cmd: cmd,
        usage: usage,
        minargs: minargs,
        func: func,
        minrank: minrank,
        hidden: hidden
    });
}

addCommand("help", `Usage: PREFIXhelp`, 0, msg => {
    let ret = "Commands: ";
    commands.forEach(cmd => {
        if (!cmd.hidden) {
            ret += ` ${prefix}${cmd.cmd}, `;
        }
    });
    ret = ret.substring(0, ret.length - 2);
    ret = ret.trim();
    sendChat(ret);
}, 0, false);

MPP.client.on("a", msg => {
    msg.args = msg.a.split(" ");
    msg.cmd = msg.args[0].toLowerCase().substring(prefix.length);
    msg.argcat = msg.a.substr(msg.cmd.length).trim();
    msg.rank = {
        _id: 0,
        name: "None"
    }

    if (msg.rank._id >= 0) {
        commands.forEach(cmd => {
            if (msg.rank._id >= cmd.minrank) {
                if (msg.cmd == cmd.cmd) {
                    if (msg.args.length - 1 >= cmd.minargs) {
                        cmd.func(msg);
                    }
                }
            }
        });
    }
});
