// ==UserScript==
// @name         Eval (>)
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://*.multiplayerpiano.com/*
// @match        https://mppclone.com/*
// @grant        none
// ==/UserScript==

if (typeof(window.client) === "undefined") {
    window.client = MPP.client;
}

client.on('a', msg => {
    msg.args = msg.a.split(" ");
    msg.cmd = msg.args[0];
    msg.argcat = msg.a.substring(msg.cmd.length).trim();

    if (msg.p.id == client.getOwnParticipant().id) {
        if (msg.cmd == ">") {
            try {
                let ret = eval(msg.argcat);
                client.sendArray([{m:'a', message:"✔️ " + ret}]);
            } catch (err) {
                if (err) {
                    client.sendArray([{m:'a', message:`❌ ${err}`}]);
                }
            }
        }
    }
});
