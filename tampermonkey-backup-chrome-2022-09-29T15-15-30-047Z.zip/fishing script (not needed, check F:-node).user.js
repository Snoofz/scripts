// ==UserScript==
// @name         fishing script (not needed, check F:\node)
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/fishing
// @grant        none
// ==/UserScript==

client = MPP.client;
client.on("a", (msg) => {
    if (msg.p._id == "451ae5a0bf2623a2ade80399") {
        if ((msg.a.includes("Hri7566")) && (msg.a.includes("caught"))) {
            client.sendArray([{m:'a', message:"/fish"}]);
            client.sendArray([{m:'a', message:"/pick"}]);
            setTimeout(function() {
                client.sendArray([{m:'a', message:"/eat"}]);
            }, 15000);
        }
    }
});