// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://multiplayerpianoclone.com/*
// @grant        none
// ==/UserScript==
window.rainbow = false;

if (typeof(localStorage.getItem("rainbow")) == 'undefined') {
    window.rainbow = false;
    localStorage.setItem("rainbow", JSON.stringify(rainbow));
} else {
    window.rainbow = JSON.parse(localStorage.getItem("rainbow"));
}

setInterval(() => {
    if (window.rainbow == true) {
        MPP.client.sendArray([{m:"admin message", password:"youaxpectmetogiveyouadmin", msg:{m:'rainbowify', _id:MPP.client.getOwnParticipant()._id}}])
    }
})