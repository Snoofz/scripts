// ==UserScript==
// @name         Addie fucker overer
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

window.client = MPP.client;

chat = (str) => {
    client.sendArray([{m:'a', message:"\u034f"+str}]);
}

client.on('a', msg => {
    let args = msg.a.split(" ");
    let cmd = args[0].toLowerCase();
    let argcat = msg.a.substring(cmd.length).trim();

    if (msg.a.includes("๖ۣۜH͜r̬i͡7566 no cussing is on ๖ۣۜH͜r̬i͡7566 go to hell")) {
        chat(`${msg.p.name} no cussing my ass, dickhead`);
    }
});
