// ==UserScript==
// @name         Selfbot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mppclone.com
// @grant        none
// ==/UserScript==

globalThis.sendChat = str => {
    return MPP.chat.send("\u034f" + str);
}

class Command {
    constructor(cmd, desc, usage, minargs = 0, func, minrank = 0, visible = true) {
        this.cmd = typeof cmd == 'object' ? cmd : [cmd];
        this.usage = usage;
        this.desc = desc;
        this.minargs = minargs;
        this.func = func;
        this.minrank = minrank;
        this.visible = visible;
    }
}

Command.getUsage = (str, pre) => {
    return str.split("%PREFIX%").join(pre);
}

class Bot {
    constructor(client) {
        this.prefix = "?";
        this.client = client;
        this.commands = [];

        this.bindEventListeners();
    }

    sendChat(str) {
        sendChat(str);
    }

    addCommand(cmd) {
        this.commands.push(cmd);
    }

    bindEventListeners() {
        this.client.on("a", msg => {
            msg.args = msg.a.split(' ');
            msg.argcat = msg.a.substring(msg.args[0].length).trim();
            msg.cmd = msg.args[0].split(this.prefix).join('');

            if (!msg.args[0].startsWith(this.prefix)) return;

            for (let cmd of this.commands) {
                let cont = false;
                aliasLoop:
                for (let c of cmd.cmd) {
                    if (msg.cmd == c) {
                        cont = true;
                        break aliasLoop;
                    }
                }

                if (!cont) continue;

                // TODO ranks

                if (msg.args.length - 1 < cmd.minargs) {
                    sendChat(`Not enough arguments. Usage: ${Command.getUsage(cmd.usage)}`);
                }

                let out;

                try {
                    out = cmd.func(msg, this);
                } catch (err) {
                    out = `An error has occurred.`;
                } finally {
                    if (out !== '') {
                        this.sendChat(out.split("\n").join(' ').split("\t").join(' '));
                    }
                }
            }
        });
    }
}

globalThis.gClient = MPP.client;
globalThis.gBot = new Bot(gClient);

gBot.addCommand(new Command(["help", 'h', 'cmds', 'cmd', 'cmnds'], "Show the bot's commands.", "%PREFIX%help <command>", 0, (msg, bot) => {
    if (!msg.args[1]) {
        let out = "Commands:";
        for (let cmd of bot.commands) {
            if (cmd.visible) {
                out += ` ${bot.prefix}${cmd.cmd[0]} | `
            }
        }
        out = out.substring(0, out.length - 2).trim();
        return out;
    } else {
        let out = `Could not find help for command '${msg.args[1]}'.`;
        let cc;
        big:
        for (let cmd of bot.commands) {
            for (let c of cmd.cmd) {
                if (msg.args[1] == c) {
                    cc = cmd;
                    break big;
                }
            }
        }

        out = `Description: ${cc.desc} | Usage: ${Command.getUsage(cc.usage, bot.prefix)}`;
        return out;
    }
}, 0, true));
