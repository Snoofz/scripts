// ==UserScript==
// @name         GridUI
// @namespace    http://tampermonkey.net/
// @version      0.0.1
// @description  Theme for MPP
// @author       Hri7566
// @match        https://mppclone.com/*
// @match        https://www.multiplayerpiano.org/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// @require      https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
// @require      https://cdn.rawgit.com/mrdoob/three.js/master/examples/js/loaders/GLTFLoader.js
// @copyright    2022+
// ==/UserScript==

$("body").prepend(`<canvas id="bg"></canvas>`);

$("#bg").css({
    position: 'fixed',
    top: 0,
    left: 0
});

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.1, 1000);

const renderer = new THREE.WebGLRenderer({
    canvas: document.querySelector("#bg"),
    alpha: true
});

const loader = new THREE.GLTFLoader();
const geometry = new THREE.TorusGeometry(10, 3, 16, 100);
const material = new THREE.MeshStandardMaterial({color: 0xff0000});
const torus = new THREE.Mesh(geometry, material);
const light = new THREE.PointLight(0xffffff);
const amblight = new THREE.AmbientLight(0xffffff);

let animating = false;

material.wireframe = true;

window.addEventListener("resize", function() {
    // https://stackoverflow.com/questions/20290402/three-js-resizing-canvas
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    renderer.setSize( window.innerWidth, window.innerHeight );
});

const start = () => {
    if (animating) return;
    animating = true;

    renderer.setPixelRatio(devicePixelRatio);
    renderer.setSize(innerWidth, innerHeight);

    camera.position.setZ(30);

    light.position.set(-20, 20, 0);

    scene.add(light);
    scene.add(amblight);
    scene.add(torus);

    const animate = () => {
        torus.rotation.x += 0.01;
        torus.rotation.y += 0.01;

        renderer.render(scene, camera);
        requestAnimationFrame(animate);
    }

    animate();
}

setTimeout(() => {
    start();
    checkForUglyButtons();
}, 2500);

const updateColor = () => {
    if ('color' in MPP.client.channel.settings)
        material.color.setHex(parseInt(MPP.client.channel.settings.color.substring(1), 16));
    if ('color2' in MPP.client.channel.settings)
        light.color.setHex(parseInt(MPP.client.channel.settings.color2.substring(1), 16));
}

MPP.client.on("ch", () => {
    updateColor();
});

let buttonRenderers = [];

const checkForUglyButtons = () => {
    let buttons = $(".ugly-button");

    $(buttons).each((i, btn) => {
        setupButton(btn);
    });
}

const setupButton = btn => {
    $(btn).css({
        "background": "none",
        "border": "none"
    });

    let text = $(`<p>${$(btn).text()}</p>`);
    $(btn).text("");

    let canv = $("<canvas></canvas>");

    $(btn).append(text);
    $(btn).append(canv);
}
















