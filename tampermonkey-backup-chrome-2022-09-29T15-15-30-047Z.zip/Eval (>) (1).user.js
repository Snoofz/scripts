// ==UserScript==
// @name         Eval (>)
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @match        https://mpp.terrium.net/*
// @match        https://piano.ourworldofpixels.com/*
// @grant        none
// ==/UserScript==


client = MPP.client;

client.on('a', msg => {
    msg.args = msg.a.split(' ');
    msg.cmd = msg.args[0].toLowerCase();
    msg.argcat = msg.a.substring(msg.cmd.length).trim();

    if (msg.cmd == ">") {
        if (msg.p.id == client.getOwnParticipant().id) {
            client.sendArray([{m:'a', message:`${eval(msg.argcat)}`}]);
        }
    }
});