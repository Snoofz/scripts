// ==UserScript==
// @name         dvd terrium
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mpp.terrium.net/*
// @grant        none
// ==/UserScript==

var client = MPP.client;

var pos = {x: Math.random()*100, y: Math.random()*100};
var vel = {x: 2/5, y: 2/7};

setInterval(() => {
    pos.x += vel.x;
    pos.y += vel.y;
    if (pos.x < 0 || pos.x > 100) {
        vel.x = -vel.x;
    }
    if (pos.y < 0 || pos.y > 100) {
        vel.y = -vel.y;
    }
    client.sendArray([{m:'m', x: pos.x, y: pos.y}]);
}, 25);