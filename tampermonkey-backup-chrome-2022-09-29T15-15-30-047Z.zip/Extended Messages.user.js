// ==UserScript==
// @name         Extended Messages
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mppclone.com
// @grant        none
// @require      file:///Z:/cmapi/dist/cmapi.dist.js
// ==/UserScript==

const gClient = MPP.client;
let cm = new cmapi(gClient);

gClient.on("custom", msg => {
    if (msg.data) {
        if (msg.data.m) {
            if (msg.data.m == "draw") return;
        }
    }

    console.log(msg);
})

window.gClient = gClient;
window.cl = window.gClient;
window.cm = cm;
