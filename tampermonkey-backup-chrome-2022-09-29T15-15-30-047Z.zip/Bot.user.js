// ==UserScript==
// @name         Bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://*.multiplayerpiano.com/*
// @match        https://www.multiplayerpiano.net/*
// @match        https://www.multiplayerpiano.org/*
// @match        https://mpp.terrium.net/*
// @match        https://mppclone.com/*
// @match        https://mpp.hri7566.info/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// @require      file:///F:/mpp-userscript/bot.user.js
// ==/UserScript==
