// ==UserScript==
// @name         CARMA's bot
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

window.client = MPP.client;

class Registry {
    constructor (data) {
        this.register = {};
        if (data) {
            try {
                this.register = data;
            } catch (err) {
                if (err) {
                    this.register = {};
                }
            }
        }
    }

    registerObject(type, namespace, obj) {
        if (obj instanceof type.classType) {
            this.register[namespace] = obj;
        }
    }
}

class RegistryType {
    constructor (classType) {
        this.classType = classType;
    }
}

window.RankTypes = class {
    static OWNER = 4;
    static ADMIN = 3;
    static MOD = 2;
    static HELPER = 1;
    static USER = 0;
    static BANNED = -1;
}

window.Command = class {
    constructor (cmd, usage, minargs, func, minrank, hidden) {
        this.cmd = cmd;
        this.usage = usage;
        this.minargs = minargs;
        this.func = func;
        this.minrank = minrank;
        this.hidden = hidden;
    }

    getFuncString() {
        return this.func.toString();
    }
}

class Rank {
    constructor (id, name) {
        this.id = id;
        this.name = name;
    }
}

window.RegistryTypes = class {
    static COMMAND = new RegistryType(Command);
    static RANK = new RegistryType(Rank);
}

class Chat {
    static send(str) {

    }
}

class MPPChat extends Chat {
    static send(str) {
        client.sendArray([{m:'a', message:`\u034f${str}`}]);
    }
}

window.Bot = class {
    constructor (prefix) {
        this.prefix = prefix;
        this.registryTypes = RegistryTypes;
        this.commandRegistry = new Registry();
        this.rankRegistry = new Registry(JSON.parse(localStorage.getItem("ranks")));
        this.rankTypes = RankTypes;
        this.command = Command;
    }

    start() {

    }

    getRank(p, namespace) {
        let ret;
        Object.keys(this.rankRegistry.register).forEach(id => {
            let rank = this.rankRegistry.register[id];
            if (id.endsWith(p._id) && id.startsWith(namespace)) {
                ret = rank;
            }
        });

        if (typeof(ret) === "undefined") {
            ret = new Rank(RankTypes.USER, "User");
        }

        return ret;
    }

    setRank(p, namespace, rankType, name) {
        this.rankRegistry.registerObject(RegistryTypes.RANK, namespace+`:ranks/${p._id}`, new Rank(rankType, name));
        this.saveRanks();
    }

    saveRanks() {
        localStorage.setItem("ranks", JSON.stringify(this.rankRegistry.register));
    }

    registerDefaultCommands(namespace) {
        let cmds = [];

        cmds[0] = new Command("help", `Usage: PREFIXhelp`, 0, (msg, bot) =>  {
            let ret = "Commands:";
            Object.keys(this.commandRegistry.register).forEach(id => {
                let cmd = this.commandRegistry.register[id];
                if (!cmd.hidden) {
                    if (msg.p.rank.id >= cmd.minrank) {
                        ret += ` ${bot.prefix}${cmd.cmd} | `;
                    }
                }
            });
            ret = ret.trim();
            ret = ret.substring(0, ret.length - 2);
            return ret;
        }, 0, false);

        cmds[2] = new Command("8ball", `Usage: PREFIX8ball`, 1, (msg, bot) => {
            let answers = [
                "It is certain",
                "It is decidedly so",
                "Without a doubt",
                "Yes - definitely",
                "You may rely on it",
                "As I see it, yes",
                "Most likely",
                "Outlook good",
                "Yes",
                "Signs point to yes",
                "Reply hazy, try again",
                "Ask again later",
                "Better not tell you now",
                "Cannot predict now",
                "Concentrate and ask again",
                "Don't count on it",
                "My reply is no",
                "My sources say no",
                "Outlook not so good",
                "Very doubtful"
            ]

            return `${answers[Math.floor(Math.random()*answers.length)]}, ${msg.p.name}.`
        }, 0, false);

        cmds[3] = new Command("about", `Usage: PREFIXabout`, 0, (msg, bot) => {
            return `This bot was TOTALLY made by CARMA.`;
        }, 0, false);

        cmds.forEach(cmd => {
            this.commandRegistry.registerObject(RegistryTypes.COMMAND, `${namespace}:${cmd.cmd}`, cmd);
        });
    }
}

window.MPPBot = class extends Bot {
    constructor (prefix, namespace) {
        super(prefix);
        this.chat = MPPChat;
        this.command = Command;
        this.started = false;
    }

    start() {
        if (!this.started) {
            this.started = true;
            this.listen();
            this.registerDefaultCommands();
        }
    }

    listen() {
        client.on("a", msg => {
            msg.args = msg.a.split(" ");
            msg.cmd = msg.args[0].split(this.prefix).join("");
            msg.argcat = msg.a.substring(this.prefix.length + msg.cmd.length).trim();
            msg.p.rank = this.getRank(msg.p, this.namespace);

            if (!msg.a.startsWith(this.prefix)) return;
            Object.keys(this.commandRegistry.register).forEach(id => {
                let cmd = this.commandRegistry.register[id];
                if (msg.p.rank.id == RankTypes.BANNED) {
                    this.chat.send("You are banned!");
                    return;
                }
                if (msg.p.rank.id >= cmd.minrank) {
                    if (msg.cmd == cmd.cmd) {
                        if (msg.args.length - 1 >= cmd.minargs) {
                            let cmdret = cmd.func(msg, this);
                            if (!cmdret) return;
                            if (cmdret.toString() !== "undefined" || cmdret.toString() !== "null") {
                                this.chat.send(cmdret.toString());
                            }
                        } else {
                            this.chat.send(`Not enough arguments provided.`);
                        }
                    }
                } else {
                    this.chat.send("hey you can't do that");
                }
            });
        });
    }
}

window.mppbot = new MPPBot("carma!");
mppbot.start();
