// ==UserScript==
// @name         add to script.js eventually
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// @require      https://cdnjs.cloudflare.com/ajax/libs/tilt.js/1.2.1/tilt.jquery.min.js
// ==/UserScript==

var buttontilt = $(".ugly-button").tilt({
    scale: 1.25
});


var nametilt = $(".name").tilt({
    scale: 1.25
});

$("#chat").after(`<div id="chat2" style="display: block;" class=""><ul></ul></div>`);

MPP.client.on("participant added", p => {
    $("#chat2 ul").append(`<li style="color: ${p.color};"><span class="name">[${p._id}] ${p.name}</span><span class="message">joined the room.</li>`);
     $(".name").tilt({
         scale: 1.25
     });
});

MPP.client.on("participant removed", p => {
    $("#chat2 ul").append(`<li style="color: ${p.color};"><span class="name">[${p._id}] ${p.name}</span><span class="message">left the room.</li>`);
     $(".name").tilt({
         scale: 1.25
     });
});

$("#chat2").on("focus", function(evt) {
    releaseKeyboard();
    $("#chat2").addClass("chatting");
});