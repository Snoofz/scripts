// ==UserScript==
// @name         bicken chot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

let prefix = "~";
let commands = new Map();

function sendChat(str) {
    MPP.client.sendArray([{m:"a", message:`\u034f${str}`}]);
}

class Command {
    constructor (cmd, usage, minargs, func, minrank, hidden) {
        if (typeof(cmd) !== 'object') cmd = [cmd];
        this.cmd = cmd;
        this.usage = usage;
        this.minargs = minargs;
        this.func = func;
        this.minrank = minrank;
        this.hidden = hidden;

        commands.set(cmd[0], this);
    }

    static getUsage(str) {
        return str.split("PREFIX").join(prefix);
    }
}

new Command(['help', 'h', 'bawk'], `PREFIXhelp [cmd]`, 0, msg => {
    if (!msg.args[1]) {
        let ret = "commands: ";
        commands.forEach(cmd => {
            if (!cmd.hidden) {
                if (msg.rank._id >= cmd.minrank) {
                    ret += `${prefix}${cmd.cmd[0]} | `;
                }
            }
        });
        ret = ret.substr(0, ret.length - 2).trim();
        return ret;
    } else {
        let ret = "usage: ";
        commands.forEach(cmd => {
            cmd.cmd.forEach(c => {
                if (msg.argcat.toLowerCase() == c.toLowerCase()) {
                    ret += Command.getUsage(cmd.usage);
                }
            });
        });
        return ret;
    }
}, 0, false);

new Command('about', `PREFIXabout`, 0, msg => {
    return `chimken birb's bot yes very good bot :)`;
}, 0, false);

let answers = [
    "As I see it, yes",
    "Ask again later",
    "Better not tell you now",
    "Cannot predict now",
    "Concentrate and ask again",
    "Don't count on it",
    "It is certain",
    "It is decidedly so",
    "Most likely",
    "My reply is no",
    "My sources say no",
    "Outlook not so good",
    "Outlook good",
    "Reply hazy, try again",
    "Signs point to yes",
    "Very doubtful",
    "Without a doubt",
    "Yes",
    "Yes - definitely",
    "You may rely on it"
];

new Command('8ball', `PREFIX8ball (question)`, 1, msg => {
    return `${Math.floor(Math.random()*answers.length)}, ${msg.p.name}.`;
}, 0, false);

new Command(['rank', 'r'], `PREFIXrank`, 0, msg => {
    return `${msg.p.name}, your rank is: ${msg.rank.name} [${msg.rank._id}]`;
}, 0, false);

new Command(['js','eval'], `PREFIXjs (js)`, 0, msg => {
    let ret;
    try {
        ret = '✓ ' + eval(msg.argcat);
    } catch (err) {
        ret = '✗ ' + err;
    }
    return ret;
}, 3, false);

class Rank {
    constructor (name, _id) {
        this.name = name;
        this._id = _id;
    }

    static getRankFromName(name) {
        if (typeof(name) !== 'string') return;
        switch (name.toLowerCase()) {
            case "owner":
                return new Rank("Owner", 3);
                break;
            case "admin":
                return new Rank("Admin", 2);
                break;
            case "mod":
                return new Rank("Moderator", 1);
                break;
            case "none":
                return new Rank("None", 0);
                break;
            case "banned":
                return new Rank("Banned", -1);
                break;
        }
    }
}

globalThis.changeRank = (_id, rank) => {
    if (typeof(rank) == 'string') rank = Rank.getRankFromName(rank);
    console.log(rank);
    localStorage.setItem("rank~"+_id, JSON.stringify(rank));
}

globalThis.getRank = (_id) => {
    return JSON.parse(localStorage.getItem("rank~"+_id));
}

MPP.client.on("a", msg => {
    msg.args = msg.a.split(' ');
    msg.cmd = msg.args[0].toLowerCase().split(prefix).join('');
    msg.argcat = msg.a.substring(msg.args[0].length).trim();
    msg.rank = getRank(msg.p._id) || Rank.getRankFromName("none");
    if (!msg.a.startsWith(prefix)) return;

    commands.forEach(cmd => {
        let cont = false;
        cmd.cmd.forEach(c => {
            if (msg.cmd == c) {
                cont = true;
            }
        });

        if (!cont) return;
        if (msg.rank._id < 0) return;
        if (msg.rank._id < cmd.minrank) return;
        if (msg.args.length - 1 < cmd.minargs) return sendChat(`not enough! here is how: ${Command.getUsage(cmd.usage)}`);

        try {
            if (typeof(cmd.func) !== "function") return;
            let out = cmd.func(msg);
            console.log(typeof out);
            if (typeof(out) === 'undefined' || out == null) return;
            sendChat(out);
        } catch (err) {
            console.error(err);
        }
    });
});













