// ==UserScript==
// @name         A-Bot
// @namespace    https://www.multiplayerpiano.com
// @version      0.1
// @description  no idea yet
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

var client = MPP.client;
var prefix = "h!";

function chat(string) {
    client.sendArray([{m:'a', message:'\u034f'+string}]);
}

client.on('a', msg => {
    let args = msg.a.split(' ');
    let cmd = args[0].toLowerCase().split(prefix).slice(1).join(prefix);
    let argcat = msg.a.substring(cmd.length).trim();
    console.log(cmd);
    switch (cmd) {
        case "help":
            chat(`Commands: ${prefix}help, ${prefix}about, ${prefix}8ball`);
            break;
        case "about":
            chat(`totally ${prefix} bot`);
            break;
        case "8ball":
            chat(`the magic 8 ball says: ${ball[Math.floor(Math.random()*ball.length)]}`);
    }
});

var ball = [
            "It is certain",
            "It is decidedly so",
            "Without a doubt",
            "Yes – definitely",
            "You may rely on it",
            "As I see it, yes",
            "Most likely",
            "Outlook good",
            "Yes",
            "Signs point to yes",
            "Don’t count on it",
            "My reply is no",
            "My sources say no",
            "Outlook not so good",
            "Very doubtful",
            "Reply hazy, try again",
            "Ask again later",
            "Better not tell you now",
            "Cannot predict now",
            "Concentrate and ask again"
        ];