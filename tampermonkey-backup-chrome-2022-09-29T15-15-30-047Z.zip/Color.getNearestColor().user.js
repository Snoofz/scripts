// ==UserScript==
// @name         Color.getNearestColor()
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

Color.getNearestColor = function (hex) {let colorarr = [];for (var color of Object.keys(Color.map)) {colorarr.push(Color.map[color].distance(Color.hexToRgb(hex)))}return Object.keys(Color.map)[colorarr.indexOf(Math.min(...colorarr))];}