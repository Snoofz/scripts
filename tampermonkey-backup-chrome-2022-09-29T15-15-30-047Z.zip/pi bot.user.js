// ==UserScript==
// @name         pi bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

// commands: pihelp pianimation picalc pivwavetext pisay piscolor piusers pibase2num pinum2base piinfo pibase2base pisstaympp pirevhexcolor pitime piabout pitranslate pitype pimath pidaily pimine pibalance pigiveaway pishop pisell pisellgem pisag pivwtcrazy pi2048memory piropron pibalance pibuy pipay secret commands: pisecretdaily piownerclaim

let cl = MPP.client;
let prefix = "pi";

cl.sendChat = (str) => {
    cl.sendArray([{
        m: "a",
        message: `\u034f${str}`
    }]);
}

let commands = [];

let addCommand = (cmd, usage, minargs, func, minrank, hidden) => {
    commands.push({
        cmd: cmd,
        usage: usage || `There is no help for this command.`,
        minargs: minargs || 0,
        func: func,
        minrank: minrank || 0,
        hidden: hidden || false
    });
}

let getUsage = (usage, pre) => {
    return usage.split("PREFIX").join(pre);
}

addCommand("help", `PREFIXhelp (command)`, 0, msg => {
    let out = "commands: ";

    const separator = ""

    commands.forEach(cmd => {
        if (!cmd.hidden) {
            out += `${prefix}${cmd.cmd} ${separator}`;
        }
    });

    out = out.substr(0, out.length - separator.length).trim();
    return out;
}, 0, false);

addCommand("animation", `PREFIXanimation`, 0, msg => {
    return `nothing yet :/ check back later`;
}, 0, false);

addCommand("calc", `PREFIXcalc`, 0, msg => {
    return `nothing yet :/ check back later`;
}, 0, false);

addCommand("vwavetext", `PREFIXvwavetext`, 0, msg => {
    return `nothing yet :/ check back later`;
}, 0, false);

addCommand("say", `PREFIXsay (string)`, 0, msg => {
    return msg.argcat;
}, 0, false);

addCommand("scolor", `PREFIXscolor`, 0, msg => {
    return `nothing yet :/ check back later`;
}, 0, false);

cl.on("a", msg => {
    msg.args = msg.a.split(" ");
    msg.cmd = msg.args[0].toLowerCase().substr(prefix.length);
    msg.argcat = msg.a.substr(msg.args[0].length + 1);

    if (!msg.a.startsWith(prefix)) return;

    commands.forEach(cmd => {
        if (msg.cmd !== cmd.cmd) return;
        if (msg.args.length - 1 < cmd.minargs) {
            cl.sendChat(`not enough arguments, usage: ${getUsage(cmd.usage, prefix)}`);
            return;
        }

        try {
            let out = cmd.func(msg);
            if (!out) return;
            if (typeof out == "string") {
                cl.sendChat(out);
            }
        } catch (err) {
            cl.sendChat("An error has occurred. Please try again later.");
            console.error(err);
        }
    });
});
