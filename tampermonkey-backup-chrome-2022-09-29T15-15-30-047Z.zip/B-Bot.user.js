// ==UserScript==
// @name         B-Bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

var client = MPP.client;
var prefix = '#';
var cmds = [];

var ranks = {
    owner: [`179aa699d8534f9bad784f90`],
    admin: [`4b7557c4614273eaf9bb0bed`],
    banned: []
};

function chat(string) {
    client.sendArray([{m:'a', message:`\u034f${string}`}]);
}

function getRank(id) {
    if (ranks.owner.indexOf(id) !== -1) {
        return {id: 2, name: "owner"};
    } else if (ranks.admin.indexOf(id) !== -1) {
        return {id: 1, name: "admin"};
    } else if (ranks.banned.indexOf(id) !== -1) {
        return {id: -1, name: "banned"};
    } else {
        return {id: 0, name: "user"};
    }
}

function addcmd(cmd, usage, minargs, func, minrank, hidden) {
    cmds.push({
        cmd: cmd,
        usage: usage,
        minargs: minargs,
        func: func,
        minrank: minrank,
        hidden: hidden
    });
}

function getUsage(cmd) {
    let found = false;
    let comm = "";
    cmds.forEach(command => {
        if (typeof(command.cmd) == "string") {
            if (cmd == command.cmd) {
                found = true;
                comm = command.usage.replace("PREFIX", this.prefix);
            }
        } else {
            command.cmd.forEach(com => {
                if (cmd == com) {
                    found = true;
                    comm = command.usage.replace("PREFIX", this.prefix);
                }
            });
        }
    });
    if (!found) {
        return `There is no help for '${cmd}'.`;
    } else {
        return comm;
    }
}

addcmd("js", null, 0, msg => {
    chat("Console: "+eval(msg.a.substring(msg.a.split(" ")[0].length + 1)));
}, 2, false);

addcmd("id", `Usage: PREFIXid`, 0, msg => {
    chat(`Your _id: ${msg.p._id}`);
}, 0, false);

addcmd("about", `Usage: PREFIXabout`, 0, msg => {
    chat(`This bot was made by ${client.getOwnParticipant().name}.`);
}, 0, false);

addcmd("wich", `Usage: PREFIXwich`, 0, msg => {
    chat(`hurb why tf you take my ${msg.p.name}wich`);
}, 0, false);

client.on('a', msg => {
    msg.p.rank = getRank(msg.p._id);
    msg.args = msg.a.split(' ');
    msg.cmd = msg.args[0].toLowerCase().split(prefix).slice(1).join(prefix);
    msg.argcat = msg.a.substring(msg.cmd.length + prefix.length).trim(' ');
    if (msg.p.rank.id !== -1) {
        cmds.forEach(cmd => {
            if (!msg.a.startsWith(prefix)) return;
            if (msg.cmd == cmd.cmd) {
                if (msg.p.rank.id >= cmd.minrank) {
                    if (msg.args.length < cmd.minargs) {
                        chat(getUsage(cmd.cmd));
                    } else {
                        cmd.func(msg);
                    }
                } else {
                    chat(`You don't have permission to use '${msg.cmd}'.`);
                }
            }
        });
    }
});