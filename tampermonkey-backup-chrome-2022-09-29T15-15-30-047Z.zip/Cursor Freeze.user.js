// ==UserScript==
// @name         Cursor Freeze
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @grant        none
// ==/UserScript==

MPP.client._events.m.pop();
MPP.client._events.m.pop();
MPP.client._events.m.pop();MPP.client._events.m.pop();MPP.client._events.m.pop();MPP.client._events.m.pop();MPP.client._events.m.pop();