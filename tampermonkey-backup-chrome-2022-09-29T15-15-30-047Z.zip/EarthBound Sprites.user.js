// ==UserScript==
// @name         EarthBound Sprites
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  try to take over the world!
// @author       Hri7566
// @match        http*://*multiplayerpiano.com/*
// @match        http*://mppclone.com/*
// @match        http*://mpp.hri7566.info/*
// @match        http*://www.multiplayerpiano.org/*
// @match        http*://www.multiplayerpiano.dev/*
// @match        http*://mppkinda.com/*
// @grant        none
// ==/UserScript==

MPP.client.on("ch", msg => {
    if (window.ebsprite) {
        ebsprite.stop(MPP.client);
    }
    $.getScript("/ebsprite.js").then(() => {
        ebsprite.start(MPP.client);
    });
});
