// ==UserScript==
// @name         eval thingy >
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

chat = (str) => {
    MPP.client.sendArray([{m:'a', message: `\u034f${str}`}])
}

let whitelist = [
    "469a7b0c2c360d8474c5888b"
];

MPP.client.on("a", msg => {
    let args = msg.a.split(' ');
    let cmd = args[0];
    let argcat = msg.a.substring(cmd.length).trim();

    if (MPP.client.getOwnParticipant()._id !== msg.p._id && whitelist.indexOf(msg.p._id) == -1) return;
    switch (cmd) {
        case ">":
            try {
                chat(`✔️ ${eval(argcat)}`);
            } catch (err) {
                if (err) {
                    chat(`❌ ${err}`);
                }
            }
            break;
    }
});