// ==UserScript==
// @name         Connect to 7566
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mpp.hri7566.info/*
// @icon         https://www.google.com/s2/favicons?domain=hri7566.info
// @grant        none
// ==/UserScript==

MPP.client.uri = "ws://localhost:7566";
MPP.client.stop();
MPP.client.start();

MPP.client.ws.addEventListener("message", msg => {
    try {
        console.log(JSON.parse(msg.data));
    } catch (err) {

    }
});
