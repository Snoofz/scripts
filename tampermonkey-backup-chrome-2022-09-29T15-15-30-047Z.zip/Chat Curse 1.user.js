// ==UserScript==
// @name         Chat Curse 1
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

let orig = MPP.chat.send;

MPP.chat.send = (str) => {
    str = str.replace(/[aeiou]/g, "o");
    str = str.replace(/[AEIOU]/g, "O");

    orig(str);
}
