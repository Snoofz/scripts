// ==UserScript==
// @name         URI Change
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.net/*
// @icon         https://www.google.com/s2/favicons?domain=multiplayerpiano.net
// @grant        none
// ==/UserScript==

MPP.client.stop();
MPP.client.uri = "ws://localhost:3000";
MPP.client.start();

MPP.client.on("hi", msg => {
    MPP.client.ws.addEventListener("message", evt => {
        console.log(evt.data);
    });
});
