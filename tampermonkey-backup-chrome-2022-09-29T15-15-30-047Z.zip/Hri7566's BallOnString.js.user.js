// ==UserScript==
// @name         Hri7566's BallOnString.js
// @namespace    http://meowbin.com/BallOnString.js
// @version      1
// @description  Turn MPP cursor into Ball on String
// @author       electrashave, mod by Hri7566
// @match        https://www.multiplayerpiano.com/*
// @match        http://mpp-evolution.com/*
// @match        http://cursors.me/piano/*
// @match        https://mpp.terrium.net/*
// @match        https://piano.ourworldofpixels.com/*
// @match        https://mpp.hri7566.info/*
// @match        https://augustberchelmann.com/piano/*
// @match        https://mpp.wolfy01.com/*
// @match        https://mppclone.com/*
// @grant        none
// ==/UserScript==

var mass = 100;
var gravity = 5;
var friction = 4;
var pos = {x: 50, y: 50};
var pos2 = {x: 50, y: 50};
var acc = {x: 0, y: 0};
var vel = {x: 0, y: 0};
var follower = "ead940199c7d9717e5149919";
var followPos = {x: 50, y: 50};

var t = 0;
var oldt = 0;
var dt = 0;

MPP.client.on("m", msg => {
    var part = MPP.client.findParticipantById(msg.id);
    if (follower !== part.id) return;
    followPos.x = +msg.x;
    followPos.y = +msg.y;
});

var updateInt = setInterval(() => {
    t = Date.now();
    dt = oldt - t;

    pos2.x = followPos.x;
    pos2.y = followPos.y;

    vel.x = ((pos2.x - pos.x) / dt) - acc.x;
    vel.y = ((pos2.y - pos.y) / dt) - acc.y - gravity;

    pos.x += vel.x;
    pos.y += vel.y;

    if (pos.y > 100 || pos.y < 0) {
        acc.y = 5;
    }

    MPP.client.sendArray([{m: "m", x: pos.x, y: pos.y}]);

    oldt = t;
}, 15);
