// ==UserScript==
// @name         helping phoenix
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

var client = MPP.client;
var prefix = '[';

function chat(string) {
    client.sendArray([{m:'a', message:'\u034f'+string}]);
}

client.on('a', msg => {
    let args = msg.a.split(' ');
    let cmd = args[0].toLowerCase();
    let argcat = msg.a.substring(cmd.length).trim();
    let prefixcmd = cmd.split('').reverse();
    for (let i = 0; i < prefix.length; i++) {
        prefixcmd.pop();
    }
    prefixcmd = prefixcmd.reverse();
    prefixcmd = prefixcmd.join('');
    if (msg.a.startsWith(prefix)) {
        switch (prefixcmd) {
            case "help":
                chat('test');
                break;
            case "prefix":
                if (argcat) {
                    prefix = argcat;
                    chat("The new prefix is "+argcat);
                }
        }
    }
});