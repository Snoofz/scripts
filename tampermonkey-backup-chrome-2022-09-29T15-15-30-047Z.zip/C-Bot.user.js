// ==UserScript==
// @name         C-Bot
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Hri7566
// @match        https://www.multiplayerpiano.com/*
// @grant        none
// ==/UserScript==

var client = MPP.client;

class Command {
    constructor (cmd, usage, minargs, func, minrank, hidden) {
        this.cmd = cmd;
        this.usage = usage;
        this.minargs = minargs;
        this.func = func;
        this.minrank = minrank || 0;
        this.hidden = hidden || false;
    }

    func() {

    }
}

class Bot {
    constructor(prefix) {
        this.prefix = prefix;
        this.commands = [];
        this.listen();
        this.ranks = localStorage.getItem('ranks')
    }

    addCommand(cmd) {
        this.commands.push(cmd);
    }

    chat(str) {
        this.client.sendArray([{m:'a', message:'\u034f'+str}]);
    }

    getRank(p) {

    }

    saveRanks() {
        localStorage.setItem('ranks', JSON.stringify(this.ranks));
    }

    listen() {
        this.client.on("a", msg => {
            msg.args = msg.a.split(' ');
            msg.cmd = msg.args[0].split(this.prefix)[1];
            msg.argcat = msg.a.substring(msg.cmd.length + this.prefix.length).trim();

        });
    }
}

const bot = new Bot();
