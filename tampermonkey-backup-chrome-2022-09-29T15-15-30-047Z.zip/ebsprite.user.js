// ==UserScript==
// @name         ebsprite
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  try to take over the world!
// @author       Hri7566
// @match        https://multiplayerpiano.com/*
// @match        https://mppclone.com/*
// @match        https://www.multiplayerpiano.org/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

let enabled = false;

MPP.client.on("hi", msg => {
    if (enabled) return;
    $.getScript("/ebsprite.js").then(() => {
        ebsprite.start(MPP.client);
        enabled = true;
    });
});
