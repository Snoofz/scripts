// ==UserScript==
// @name         Voice Chat for MPPClone
// @namespace    https://multiplayerpiano.org
// @version      1.0.0
// @description  Voice Chat for MPPClone
// @author       Foonix, Hri7566
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?domain=mppclone.com
// @grant        none
// ==/UserScript==

let mute = true;
MPP.client.sendArray([{ m: "+custom" }]);

window.msgBox = (title, text, html) => {
    new MPP.Notification({
        id: "hri-bot-msg",
        title: title,
        text: text,
        target: "#piano",
        duration: 7000,
        html: html
    });
}

let a;

let audioIN = { audio: true };

    navigator.mediaDevices.getUserMedia({ audio: true })

      .then(function(mediaStreamObj) {

        document.addEventListener("keypress", evt => {
            if (evt.key == "\\" && !$("#chat").hasClass("chatting")) {
                if (mute == true) {
                    msgBox("Voice Chat", "Voice chat is now enabled.");
                    a = setInterval(() => {
                        let mediaRecorder = new MediaRecorder(mediaStreamObj);
                        mediaRecorder.start();
                        mediaRecorder.ondataavailable = function(ev) {
                            var reader = new FileReader();
                            reader.readAsDataURL(ev.data);
                            reader.onloadend = function() {
                                var base64data = reader.result;
                                MPP.client.sendArray([{ m: "custom", data: { m: "vc", "vcData": base64data.toString() }, target: { mode: "subscribed", global: false } }]);
                            }
                            // if (mediaRecorder.state == "recording") mediaRecorder.stop();
                        }
                        setTimeout(() => {
                            mediaRecorder.stop();
                        }, 1050);
                    }, 1000);
                    mute = false;
                } else if (mute == false) {
                    msgBox("Voice Chat", "Voice chat is now disabled.");
                    clearInterval(a);
                    // mediaRecorder.stop();
                    mute = true;
                }
            }
        });

        let dataArray = [];
      })

      // If any error occurs then handles the error
      .catch(function(err) {
        console.error(err);
      });

      $(document).ready(() => {
        setTimeout(() => {
            MPP.client.sendArray([{m: "+custom"}]);
        }, 3000);

        MPP.client.on("custom", cu => {
            // if (cu.p == MPP.client.getOwnParticipant()._id) return;

            // play audio from msg
            if (!('m' in cu)) {
                return;
            }

            let msg = cu.data;

            if (msg.m == "vc") {
                // convert msg.vcData from string to blob
                let audio = new Audio(msg.vcData);

                // play audio when loaded
                audio.addEventListener('loadeddata', () => {
                    audio.play();
                });
            }
        });
    });