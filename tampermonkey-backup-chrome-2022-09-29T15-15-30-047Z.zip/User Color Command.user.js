// ==UserScript==
// @name         User Color Command
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://mppclone.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mppclone.com
// @grant        none
// ==/UserScript==

let prefix = '!';

const sendChat = str => {
    MPP.client.sendArray([{m: "a", message: `\u034f${str}`}]);
}

MPP.client.on("a", (msg) => {
    msg.args = msg.a.split(' ');
    msg.argcat = msg.a.substring(msg.args[0].length).trim();

    if (!msg.a.startsWith(prefix)) return;
    msg.cmd = msg.args[0].substring(prefix.length).trim();

    switch (msg.cmd) {
        case 'mppuc':
        case 'mppc':
        case 'mppcolor':
            if (!msg.args[1]) {
                sendChat("Your color is " + (new Color(msg.p.color).getName().replace('A ', 'a ')));
                break;
            } else {
                let c = new Color(msg.argcat);
                if (c) {
                    sendChat("That color looks like " + c.getName().replace('A ', 'a '));
                    break;
                } else {
                    sendChat("no color :(");
                    break;
                }
            }
            break;
        case 'rules':
            sendChat("Rules: be clown or kick");
            break;
    }
});