MPP.client.sendArray([
	{
		m: 'userset',
		set: {
			name:
				'\u034f' +
				fw(`${nmbpname} [${sectoform(elaspe)} | ${sectoform(extsec(current))}]`)
		}
	}
]);
